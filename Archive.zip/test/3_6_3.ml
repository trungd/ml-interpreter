let x = match [1;2;3] with 
  [] -> true | ls::ls -> false;;