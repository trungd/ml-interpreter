let x = 1 let y = x + 1;;
x = 10;;
let x = 1 let y = x * 2 let z = y * 3;;