let a = [1;2;3];;
let b = [1+3;2+5;3*7];;
let c = [true; false; true];;
let d = [];;
let e = [4];;
let a = [1;2;3] in match a with head::tail -> head;;