let x = 100 and y = x in x + y;; (* x = 100 and y = 10 *)
let x = 20 in let x = 100 and y = x in x + y;; (* x = 100 and y = 20 *)