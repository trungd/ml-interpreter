1 + if true then 2 else 3;;
1 + let x = 4 in x;;
1 + match [1;2] with x::rest -> x;;