let f = fun a -> a;;
f f;;