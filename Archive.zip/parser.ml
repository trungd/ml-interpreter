
module MenhirBasics = struct
  
  exception Error
  
  type token = 
    | WITH
    | TYPE_INT
    | TYPE_ID of (
# 18 "parser.mly"
       (Syntax.id)
# 13 "parser.ml"
  )
    | TYPE_BOOL
    | TWOCOLONS
    | TRUE
    | THEN
    | SINGQUO
    | SEP
    | SEMISEMI
    | SEMI
    | RSQBRACKET
    | RPAREN
    | REC
    | RARROW
    | PLUS
    | OR
    | MULT
    | MINUS
    | MATCH
    | LT
    | LSQBRACKET
    | LPAREN
    | LET
    | INTV of (
# 16 "parser.mly"
       (int)
# 39 "parser.ml"
  )
    | IN
    | IF
    | ID of (
# 17 "parser.mly"
       (Syntax.id)
# 46 "parser.ml"
  )
    | GT
    | FUN
    | FALSE
    | EQ
    | EMPTYLIST
    | ELSE
    | DFUN
    | COMMENT
    | COLON
    | ANDKW
    | AND
  
end

include MenhirBasics

let _eRR =
  MenhirBasics.Error

type _menhir_env = {
  _menhir_lexer: Lexing.lexbuf -> token;
  _menhir_lexbuf: Lexing.lexbuf;
  _menhir_token: token;
  mutable _menhir_error: bool
}

and _menhir_state = 
  | MenhirState231
  | MenhirState225
  | MenhirState224
  | MenhirState222
  | MenhirState221
  | MenhirState220
  | MenhirState218
  | MenhirState217
  | MenhirState215
  | MenhirState214
  | MenhirState213
  | MenhirState210
  | MenhirState209
  | MenhirState208
  | MenhirState207
  | MenhirState206
  | MenhirState205
  | MenhirState204
  | MenhirState201
  | MenhirState200
  | MenhirState197
  | MenhirState196
  | MenhirState193
  | MenhirState192
  | MenhirState190
  | MenhirState188
  | MenhirState187
  | MenhirState186
  | MenhirState185
  | MenhirState184
  | MenhirState182
  | MenhirState180
  | MenhirState177
  | MenhirState176
  | MenhirState173
  | MenhirState172
  | MenhirState171
  | MenhirState162
  | MenhirState161
  | MenhirState159
  | MenhirState158
  | MenhirState154
  | MenhirState153
  | MenhirState152
  | MenhirState151
  | MenhirState150
  | MenhirState148
  | MenhirState147
  | MenhirState146
  | MenhirState145
  | MenhirState144
  | MenhirState142
  | MenhirState141
  | MenhirState139
  | MenhirState138
  | MenhirState137
  | MenhirState135
  | MenhirState133
  | MenhirState132
  | MenhirState131
  | MenhirState130
  | MenhirState129
  | MenhirState128
  | MenhirState127
  | MenhirState124
  | MenhirState123
  | MenhirState122
  | MenhirState119
  | MenhirState118
  | MenhirState117
  | MenhirState115
  | MenhirState113
  | MenhirState112
  | MenhirState111
  | MenhirState110
  | MenhirState109
  | MenhirState108
  | MenhirState107
  | MenhirState106
  | MenhirState105
  | MenhirState103
  | MenhirState102
  | MenhirState101
  | MenhirState99
  | MenhirState97
  | MenhirState95
  | MenhirState91
  | MenhirState89
  | MenhirState84
  | MenhirState78
  | MenhirState74
  | MenhirState73
  | MenhirState72
  | MenhirState61
  | MenhirState59
  | MenhirState52
  | MenhirState49
  | MenhirState46
  | MenhirState40
  | MenhirState36
  | MenhirState35
  | MenhirState33
  | MenhirState32
  | MenhirState29
  | MenhirState27
  | MenhirState22
  | MenhirState16
  | MenhirState12
  | MenhirState11
  | MenhirState10
  | MenhirState9
  | MenhirState8
  | MenhirState7
  | MenhirState5
  | MenhirState0

# 1 "parser.mly"
  
open Syntax
open Typing

# 196 "parser.ml"

let rec _menhir_run27 : _menhir_env -> (('ttv_tail * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | DFUN ->
        _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | EMPTYLIST ->
        _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | EQ ->
        _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | FALSE ->
        _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | FUN ->
        _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | GT ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | ID _v ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState27 _v
    | IF ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | INTV _v ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState27 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState27

and _menhir_goto_TypeExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_TypeExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState16 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv839 * _menhir_state) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv835 * _menhir_state) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv833 * _menhir_state) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s), _, (t : 'tv_TypeExpr)) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_TypeExpr = 
# 37 "parser.mly"
                           ( t )
# 268 "parser.ml"
             in
            _menhir_goto_TypeExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv834)) : 'freshtv836)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv837 * _menhir_state) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv838)) : 'freshtv840)
    | MenhirState12 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv843 * _menhir_state * (
# 17 "parser.mly"
       (Syntax.id)
# 283 "parser.ml"
        )) * _menhir_state) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv841 * _menhir_state * (
# 17 "parser.mly"
       (Syntax.id)
# 289 "parser.ml"
        )) * _menhir_state) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, (x : (
# 17 "parser.mly"
       (Syntax.id)
# 294 "parser.ml"
        ))), _), _, (ty : 'tv_TypeExpr)) = _menhir_stack in
        let _2 = () in
        let _v : 'tv_IdWithTypeExpr = 
# 25 "parser.mly"
                         ( (x, ty) )
# 300 "parser.ml"
         in
        _menhir_goto_IdWithTypeExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv842)) : 'freshtv844)
    | MenhirState103 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv849 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RARROW ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv845 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState105 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState105 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState105) : 'freshtv846)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv847 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv848)) : 'freshtv850)
    | MenhirState139 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv855 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv851 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState141 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState141 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState141) : 'freshtv852)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv853 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv854)) : 'freshtv856)
    | MenhirState148 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv861 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((('freshtv857 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState150 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState150 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState150
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState150) : 'freshtv858)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((('freshtv859 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv860)) : 'freshtv862)
    | MenhirState215 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv867 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((('freshtv863 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState217 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState217 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState217
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState217) : 'freshtv864)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((('freshtv865 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv866)) : 'freshtv868)
    | MenhirState222 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv873 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((('freshtv869 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState224 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState224 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState224
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState224) : 'freshtv870)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((('freshtv871 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv872)) : 'freshtv874)
    | _ ->
        _menhir_fail ()

and _menhir_reduce101 : _menhir_env -> 'ttv_tail * _menhir_state * 'tv_TypeAExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (_menhir_stack, _menhir_s, (t : 'tv_TypeAExpr)) = _menhir_stack in
    let _v : 'tv_TypeExpr = 
# 38 "parser.mly"
              ( t )
# 617 "parser.ml"
     in
    _menhir_goto_TypeExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_MatchPatternExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_MatchPatternExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv831 * _menhir_state * 'tv_MatchPatternExpr) = Obj.magic _menhir_stack in
    ((assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | RARROW ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv827 * _menhir_state * 'tv_MatchPatternExpr) = Obj.magic _menhir_stack in
        ((let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | AND ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | DFUN ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | EMPTYLIST ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | EQ ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | FALSE ->
            _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | FUN ->
            _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | GT ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | ID _v ->
            _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState171 _v
        | IF ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | INTV _v ->
            _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState171 _v
        | LET ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | LPAREN ->
            _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | LSQBRACKET ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | LT ->
            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | MATCH ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | MULT ->
            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | OR ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | PLUS ->
            _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | TRUE ->
            _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState171) : 'freshtv828)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv829 * _menhir_state * 'tv_MatchPatternExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv830)) : 'freshtv832)

and _menhir_run127 : _menhir_env -> ('ttv_tail * _menhir_state) * _menhir_state * 'tv_LetAndExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | DFUN ->
        _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | EMPTYLIST ->
        _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | EQ ->
        _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | FALSE ->
        _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | FUN ->
        _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | GT ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | ID _v ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState127 _v
    | IF ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | INTV _v ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState127 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState127
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState127

and _menhir_goto_LetRecAndExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_LetRecAndExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState10 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv809 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | IN ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv807 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv808)) : 'freshtv810)
    | MenhirState119 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv813 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv811 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
        ((let ((((((_menhir_stack, _menhir_s, (x : 'tv_IdWithTypeExpr)), _), _, (param : 'tv_IdWithTypeExpr)), _, (e : 'tv_Expr)), _), _, (ls : 'tv_LetRecAndExpr)) = _menhir_stack in
        let _7 = () in
        let _5 = () in
        let _3 = () in
        let _2 = () in
        let _v : 'tv_LetRecAndExpr = 
# 51 "parser.mly"
                                                                                    ( (x, param, e)::ls )
# 765 "parser.ml"
         in
        _menhir_goto_LetRecAndExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv812)) : 'freshtv814)
    | MenhirState124 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv817 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv815 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s, (x : 'tv_IdWithTypeExpr)), _, (param : 'tv_IdWithTypeExpr)), _, (e : 'tv_Expr)), _), _, (ls : 'tv_LetRecAndExpr)) = _menhir_stack in
        let _5 = () in
        let _3 = () in
        let _v : 'tv_LetRecAndExpr = 
# 50 "parser.mly"
                                                                         ( (x, param, e)::ls )
# 779 "parser.ml"
         in
        _menhir_goto_LetRecAndExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv816)) : 'freshtv818)
    | MenhirState177 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv825 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | IN ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv821 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv819 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s), _), _, (ls : 'tv_LetRecAndExpr)) = _menhir_stack in
            let _4 = () in
            let _2 = () in
            let _1 = () in
            let _v : (
# 21 "parser.mly"
      (Syntax.program)
# 802 "parser.ml"
            ) = 
# 69 "parser.mly"
                                    ( RecDecls ls )
# 806 "parser.ml"
             in
            _menhir_goto_toplevel _menhir_env _menhir_stack _menhir_s _v) : 'freshtv820)) : 'freshtv822)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv823 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv824)) : 'freshtv826)
    | _ ->
        _menhir_fail ()

and _menhir_goto_AppExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_AppExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState52 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv801 * _menhir_state * 'tv_MExpr)) * _menhir_state * 'tv_AppExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EMPTYLIST ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState59
        | FALSE ->
            _menhir_run81 _menhir_env (Obj.magic _menhir_stack) MenhirState59
        | ID _v ->
            _menhir_run80 _menhir_env (Obj.magic _menhir_stack) MenhirState59 _v
        | INTV _v ->
            _menhir_run79 _menhir_env (Obj.magic _menhir_stack) MenhirState59 _v
        | LPAREN ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState59
        | LSQBRACKET ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState59
        | TRUE ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState59
        | ANDKW | ELSE | EQ | GT | IN | LET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv799 * _menhir_state * 'tv_MExpr)) * _menhir_state * 'tv_AppExpr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, (l : 'tv_MExpr)), _, (r : 'tv_AppExpr)) = _menhir_stack in
            let _2 = () in
            let _v : 'tv_MExpr = 
# 115 "parser.mly"
                           ( BinOp (Mult, l, r) )
# 851 "parser.ml"
             in
            _menhir_goto_MExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv800)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState59) : 'freshtv802)
    | MenhirState0 | MenhirState224 | MenhirState220 | MenhirState205 | MenhirState217 | MenhirState213 | MenhirState209 | MenhirState200 | MenhirState184 | MenhirState196 | MenhirState192 | MenhirState5 | MenhirState171 | MenhirState7 | MenhirState159 | MenhirState8 | MenhirState150 | MenhirState152 | MenhirState144 | MenhirState146 | MenhirState131 | MenhirState141 | MenhirState137 | MenhirState127 | MenhirState122 | MenhirState117 | MenhirState27 | MenhirState29 | MenhirState108 | MenhirState110 | MenhirState105 | MenhirState40 | MenhirState46 | MenhirState99 | MenhirState97 | MenhirState95 | MenhirState49 | MenhirState61 | MenhirState73 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv805 * _menhir_state * 'tv_AppExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EMPTYLIST ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState78
        | FALSE ->
            _menhir_run81 _menhir_env (Obj.magic _menhir_stack) MenhirState78
        | ID _v ->
            _menhir_run80 _menhir_env (Obj.magic _menhir_stack) MenhirState78 _v
        | INTV _v ->
            _menhir_run79 _menhir_env (Obj.magic _menhir_stack) MenhirState78 _v
        | LPAREN ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState78
        | LSQBRACKET ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState78
        | TRUE ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState78
        | ANDKW | ELSE | EQ | GT | IN | LET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv803 * _menhir_state * 'tv_AppExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, (e : 'tv_AppExpr)) = _menhir_stack in
            let _v : 'tv_MExpr = 
# 117 "parser.mly"
              ( e )
# 885 "parser.ml"
             in
            _menhir_goto_MExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv804)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState78) : 'freshtv806)
    | _ ->
        _menhir_fail ()

and _menhir_run130 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 17 "parser.mly"
       (Syntax.id)
# 898 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | COLON ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState130
    | ID _v ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState130 _v
    | LPAREN ->
        _menhir_run33 _menhir_env (Obj.magic _menhir_stack) MenhirState130
    | EQ ->
        _menhir_reduce54 _menhir_env (Obj.magic _menhir_stack)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState130

and _menhir_run131 : _menhir_env -> 'ttv_tail * _menhir_state * 'tv_IdWithTypeExpr -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | DFUN ->
        _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | EMPTYLIST ->
        _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | EQ ->
        _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | FALSE ->
        _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | FUN ->
        _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | GT ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | ID _v ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState131 _v
    | IF ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | INTV _v ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState131 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState131
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState131

and _menhir_goto_TypeAExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_TypeAExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState16 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv781 * _menhir_state * 'tv_TypeAExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RARROW ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv777 * _menhir_state * 'tv_TypeAExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | TYPE_BOOL ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | TYPE_ID _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState22 _v
            | TYPE_INT ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState22) : 'freshtv778)
        | RPAREN ->
            _menhir_reduce101 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv779 * _menhir_state * 'tv_TypeAExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv780)) : 'freshtv782)
    | MenhirState22 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv795 * _menhir_state * 'tv_TypeAExpr)) * _menhir_state * 'tv_TypeAExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv793 * _menhir_state * 'tv_TypeAExpr)) * _menhir_state * 'tv_TypeAExpr) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, (t1 : 'tv_TypeAExpr)), _, (t2 : 'tv_TypeAExpr)) = _menhir_stack in
        let _2 = () in
        let _v : 'tv_TypeFunExpr = 
# 34 "parser.mly"
                                   ( TyFun(t1, t2) )
# 1012 "parser.ml"
         in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv791) = _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_TypeFunExpr) = _v in
        ((let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv789 * _menhir_state) * _menhir_state * 'tv_TypeFunExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv785 * _menhir_state) * _menhir_state * 'tv_TypeFunExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv783 * _menhir_state) * _menhir_state * 'tv_TypeFunExpr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s), _, (t : 'tv_TypeFunExpr)) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_TypeExpr = 
# 39 "parser.mly"
                              ( t )
# 1036 "parser.ml"
             in
            _menhir_goto_TypeExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv784)) : 'freshtv786)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv787 * _menhir_state) * _menhir_state * 'tv_TypeFunExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv788)) : 'freshtv790)) : 'freshtv792)) : 'freshtv794)) : 'freshtv796)
    | MenhirState222 | MenhirState215 | MenhirState148 | MenhirState139 | MenhirState103 | MenhirState12 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv797 * _menhir_state * 'tv_TypeAExpr) = Obj.magic _menhir_stack in
        (_menhir_reduce101 _menhir_env (Obj.magic _menhir_stack) : 'freshtv798)
    | _ ->
        _menhir_fail ()

and _menhir_reduce22 : _menhir_env -> 'ttv_tail * _menhir_state * 'tv_AExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (_menhir_stack, _menhir_s, (e : 'tv_AExpr)) = _menhir_stack in
    let _v : 'tv_AppExpr = 
# 131 "parser.mly"
            ( e )
# 1059 "parser.ml"
     in
    _menhir_goto_AppExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_AppParamListExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_AppParamListExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState59 | MenhirState78 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv771 * _menhir_state * 'tv_AppExpr) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_AppParamListExpr) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv769 * _menhir_state * 'tv_AppExpr) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let ((ls : 'tv_AppParamListExpr) : 'tv_AppParamListExpr) = _v in
        ((let (_menhir_stack, _menhir_s, (e : 'tv_AppExpr)) = _menhir_stack in
        let _v : 'tv_AppExpr = 
# 130 "parser.mly"
                                  ( AppExp(e, ls) )
# 1079 "parser.ml"
         in
        _menhir_goto_AppExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv770)) : 'freshtv772)
    | MenhirState84 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv775 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_AppParamListExpr) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv773 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let ((ls : 'tv_AppParamListExpr) : 'tv_AppParamListExpr) = _v in
        ((let (_menhir_stack, _menhir_s, (e : 'tv_AExpr)) = _menhir_stack in
        let _v : 'tv_AppParamListExpr = 
# 139 "parser.mly"
                                 ( e::ls )
# 1095 "parser.ml"
         in
        _menhir_goto_AppParamListExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv774)) : 'freshtv776)
    | _ ->
        _menhir_fail ()

and _menhir_run60 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce2 _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run61 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | DFUN ->
        _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | EMPTYLIST ->
        _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | EQ ->
        _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | FALSE ->
        _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | FUN ->
        _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | GT ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | ID _v ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState61 _v
    | IF ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | INTV _v ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState61 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState61
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState61

and _menhir_run79 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 16 "parser.mly"
       (int)
# 1158 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce1 _menhir_env (Obj.magic _menhir_stack) _menhir_s _v

and _menhir_run80 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 17 "parser.mly"
       (Syntax.id)
# 1167 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce4 _menhir_env (Obj.magic _menhir_stack) _menhir_s _v

and _menhir_run81 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce3 _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_goto_toplevel : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 21 "parser.mly"
      (Syntax.program)
# 1181 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv767) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : (
# 21 "parser.mly"
      (Syntax.program)
# 1190 "parser.ml"
    )) = _v in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv765) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((_1 : (
# 21 "parser.mly"
      (Syntax.program)
# 1198 "parser.ml"
    )) : (
# 21 "parser.mly"
      (Syntax.program)
# 1202 "parser.ml"
    )) = _v in
    (Obj.magic _1 : 'freshtv766)) : 'freshtv768)

and _menhir_reduce92 : _menhir_env -> (((((('ttv_tail * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (((((_menhir_stack, _menhir_s), _, (x : 'tv_IdWithTypeExpr)), _, (ls_param : 'tv_FunParamListExpr)), _, (t : 'tv_TypeExpr)), _, (e : 'tv_Expr)) = _menhir_stack in
    let _6 = () in
    let _4 = () in
    let _1 = () in
    let _v : 'tv_TopLetExpr = 
# 59 "parser.mly"
                                                                            ( [(x, FunExp(ls_param, t, e))] )
# 1215 "parser.ml"
     in
    _menhir_goto_TopLetExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce91 : _menhir_env -> (((('ttv_tail * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let ((((_menhir_stack, _menhir_s), _, (x : 'tv_IdWithTypeExpr)), _, (ls_param : 'tv_FunParamListExpr)), _, (e : 'tv_Expr)) = _menhir_stack in
    let _4 = () in
    let _1 = () in
    let _v : 'tv_TopLetExpr = 
# 58 "parser.mly"
                                                           ( [(x, FunExp(ls_param, TyNone, e))] )
# 1227 "parser.ml"
     in
    _menhir_goto_TopLetExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_TopLetExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_TopLetExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState206 | MenhirState210 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv755 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state * 'tv_TopLetExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv753 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state * 'tv_TopLetExpr) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s), _, (x : 'tv_IdWithTypeExpr)), _), _, (e : 'tv_Expr)), _, (ls : 'tv_TopLetExpr)) = _menhir_stack in
        let _3 = () in
        let _1 = () in
        let _v : 'tv_TopLetExpr = 
# 56 "parser.mly"
                                               ( (x, e)::ls )
# 1246 "parser.ml"
         in
        _menhir_goto_TopLetExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv754)) : 'freshtv756)
    | MenhirState0 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv763 * _menhir_state * 'tv_TopLetExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv759 * _menhir_state * 'tv_TopLetExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv757 * _menhir_state * 'tv_TopLetExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, (ls : 'tv_TopLetExpr)) = _menhir_stack in
            let _2 = () in
            let _v : (
# 21 "parser.mly"
      (Syntax.program)
# 1265 "parser.ml"
            ) = 
# 70 "parser.mly"
                         ( Decls ls )
# 1269 "parser.ml"
             in
            _menhir_goto_toplevel _menhir_env _menhir_stack _menhir_s _v) : 'freshtv758)) : 'freshtv760)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv761 * _menhir_state * 'tv_TopLetExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv762)) : 'freshtv764)
    | _ ->
        _menhir_fail ()

and _menhir_run207 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState207 _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState207

and _menhir_goto_TopLetRecExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_TopLetRecExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState185 | MenhirState193 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((((('freshtv739 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) * _menhir_state * 'tv_TopLetRecExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((((('freshtv737 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) * _menhir_state * 'tv_TopLetRecExpr) = Obj.magic _menhir_stack in
        ((let (((((((_menhir_stack, _menhir_s), _), _, (x : 'tv_IdWithTypeExpr)), _), _, (param : 'tv_IdWithTypeExpr)), _, (e : 'tv_Expr)), _, (ls : 'tv_TopLetRecExpr)) = _menhir_stack in
        let _7 = () in
        let _5 = () in
        let _4 = () in
        let _2 = () in
        let _1 = () in
        let _v : 'tv_TopLetRecExpr = 
# 63 "parser.mly"
                                                                                      ( (x, param, e)::ls )
# 1313 "parser.ml"
         in
        _menhir_goto_TopLetRecExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv738)) : 'freshtv740)
    | MenhirState201 | MenhirState197 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv743 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) * _menhir_state * 'tv_TopLetRecExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv741 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) * _menhir_state * 'tv_TopLetRecExpr) = Obj.magic _menhir_stack in
        ((let ((((((_menhir_stack, _menhir_s), _), _, (x : 'tv_IdWithTypeExpr)), _, (param : 'tv_IdWithTypeExpr)), _, (e : 'tv_Expr)), _, (ls : 'tv_TopLetRecExpr)) = _menhir_stack in
        let _5 = () in
        let _2 = () in
        let _1 = () in
        let _v : 'tv_TopLetRecExpr = 
# 62 "parser.mly"
                                                                           ( (x, param, e)::ls )
# 1328 "parser.ml"
         in
        _menhir_goto_TopLetRecExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv742)) : 'freshtv744)
    | MenhirState0 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv751 * _menhir_state * 'tv_TopLetRecExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv747 * _menhir_state * 'tv_TopLetRecExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv745 * _menhir_state * 'tv_TopLetRecExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, (ls : 'tv_TopLetRecExpr)) = _menhir_stack in
            let _2 = () in
            let _v : (
# 21 "parser.mly"
      (Syntax.program)
# 1347 "parser.ml"
            ) = 
# 72 "parser.mly"
                            ( RecDecls ls )
# 1351 "parser.ml"
             in
            _menhir_goto_toplevel _menhir_env _menhir_stack _menhir_s _v) : 'freshtv746)) : 'freshtv748)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv749 * _menhir_state * 'tv_TopLetRecExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv750)) : 'freshtv752)
    | _ ->
        _menhir_fail ()

and _menhir_run186 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | REC ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv735 * _menhir_state) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState186 in
        ((let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ID _v ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState187 _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState187) : 'freshtv736)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState186

and _menhir_goto_MatchListExprs : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_MatchListExprs -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState173 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv719 * _menhir_state * 'tv_MatchPatternExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_MatchListExprs) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv717 * _menhir_state * 'tv_MatchPatternExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let ((match_list : 'tv_MatchListExprs) : 'tv_MatchListExprs) = _v in
        ((let (((_menhir_stack, _menhir_s, (match_pattern : 'tv_MatchPatternExpr)), _, (exp : 'tv_Expr)), _) = _menhir_stack in
        let _4 = () in
        let _2 = () in
        let _v : 'tv_MatchListExprs = 
# 202 "parser.mly"
                                                                                 ( (match_pattern, exp) :: match_list )
# 1407 "parser.ml"
         in
        _menhir_goto_MatchListExprs _menhir_env _menhir_stack _menhir_s _v) : 'freshtv718)) : 'freshtv720)
    | MenhirState162 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv733 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_MatchListExprs) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv731 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let ((match_list : 'tv_MatchListExprs) : 'tv_MatchListExprs) = _v in
        ((let (((_menhir_stack, _menhir_s), _, (exp : 'tv_Expr)), _) = _menhir_stack in
        let _3 = () in
        let _1 = () in
        let _v : 'tv_MatchExpr = 
# 206 "parser.mly"
                                                  ( MatchExp(exp, match_list) )
# 1425 "parser.ml"
         in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv729) = _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_MatchExpr) = _v in
        ((match _menhir_s with
        | MenhirState99 | MenhirState97 | MenhirState95 | MenhirState52 | MenhirState49 ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv723) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_MatchExpr) = _v in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv721) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let ((e : 'tv_MatchExpr) : 'tv_MatchExpr) = _v in
            ((let _v : 'tv_AExprEx = 
# 162 "parser.mly"
              ( e )
# 1444 "parser.ml"
             in
            _menhir_goto_AExprEx _menhir_env _menhir_stack _menhir_s _v) : 'freshtv722)) : 'freshtv724)
        | MenhirState0 | MenhirState224 | MenhirState220 | MenhirState217 | MenhirState213 | MenhirState209 | MenhirState205 | MenhirState200 | MenhirState196 | MenhirState192 | MenhirState184 | MenhirState171 | MenhirState5 | MenhirState159 | MenhirState7 | MenhirState8 | MenhirState152 | MenhirState150 | MenhirState146 | MenhirState144 | MenhirState141 | MenhirState137 | MenhirState131 | MenhirState127 | MenhirState122 | MenhirState117 | MenhirState27 | MenhirState110 | MenhirState108 | MenhirState29 | MenhirState105 | MenhirState40 | MenhirState46 | MenhirState73 | MenhirState61 ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv727) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_MatchExpr) = _v in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv725) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let ((e : 'tv_MatchExpr) : 'tv_MatchExpr) = _v in
            ((let _v : 'tv_Expr = 
# 87 "parser.mly"
              ( e )
# 1459 "parser.ml"
             in
            _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv726)) : 'freshtv728)
        | _ ->
            _menhir_fail ()) : 'freshtv730)) : 'freshtv732)) : 'freshtv734)
    | _ ->
        _menhir_fail ()

and _menhir_run163 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv713 * _menhir_state) = Obj.magic _menhir_stack in
        let (_v : (
# 17 "parser.mly"
       (Syntax.id)
# 1479 "parser.ml"
        )) = _v in
        ((let _menhir_stack = (_menhir_stack, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RSQBRACKET ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv709 * _menhir_state) * (
# 17 "parser.mly"
       (Syntax.id)
# 1490 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv707 * _menhir_state) * (
# 17 "parser.mly"
       (Syntax.id)
# 1497 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s), (id : (
# 17 "parser.mly"
       (Syntax.id)
# 1502 "parser.ml"
            ))) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_MatchPatternExpr = 
# 198 "parser.mly"
                                ( SingleElementList(id) )
# 1509 "parser.ml"
             in
            _menhir_goto_MatchPatternExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv708)) : 'freshtv710)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv711 * _menhir_state) * (
# 17 "parser.mly"
       (Syntax.id)
# 1519 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv712)) : 'freshtv714)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv715 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv716)

and _menhir_run166 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 17 "parser.mly"
       (Syntax.id)
# 1534 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | TWOCOLONS ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv703 * _menhir_state * (
# 17 "parser.mly"
       (Syntax.id)
# 1546 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ID _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv699 * _menhir_state * (
# 17 "parser.mly"
       (Syntax.id)
# 1556 "parser.ml"
            ))) = Obj.magic _menhir_stack in
            let (_v : (
# 17 "parser.mly"
       (Syntax.id)
# 1561 "parser.ml"
            )) = _v in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv697 * _menhir_state * (
# 17 "parser.mly"
       (Syntax.id)
# 1568 "parser.ml"
            ))) = Obj.magic _menhir_stack in
            let ((id2 : (
# 17 "parser.mly"
       (Syntax.id)
# 1573 "parser.ml"
            )) : (
# 17 "parser.mly"
       (Syntax.id)
# 1577 "parser.ml"
            )) = _v in
            ((let (_menhir_stack, _menhir_s, (id1 : (
# 17 "parser.mly"
       (Syntax.id)
# 1582 "parser.ml"
            ))) = _menhir_stack in
            let _2 = () in
            let _v : 'tv_MatchPatternExpr = 
# 199 "parser.mly"
                            ( ListHeadTail(id1, id2) )
# 1588 "parser.ml"
             in
            _menhir_goto_MatchPatternExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv698)) : 'freshtv700)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv701 * _menhir_state * (
# 17 "parser.mly"
       (Syntax.id)
# 1598 "parser.ml"
            ))) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv702)) : 'freshtv704)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv705 * _menhir_state * (
# 17 "parser.mly"
       (Syntax.id)
# 1609 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv706)

and _menhir_run169 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv695) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_MatchPatternExpr = 
# 197 "parser.mly"
              ( EmptyList )
# 1624 "parser.ml"
     in
    _menhir_goto_MatchPatternExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv696)

and _menhir_goto_ListItemExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_ListItemExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState7 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv689 * _menhir_state) * _menhir_state * 'tv_ListItemExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RSQBRACKET ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv685 * _menhir_state) * _menhir_state * 'tv_ListItemExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv683 * _menhir_state) * _menhir_state * 'tv_ListItemExpr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s), _, (ls : 'tv_ListItemExpr)) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_ListExpr = 
# 193 "parser.mly"
                                          ( ListExp(ls) )
# 1650 "parser.ml"
             in
            _menhir_goto_ListExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv684)) : 'freshtv686)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv687 * _menhir_state) * _menhir_state * 'tv_ListItemExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv688)) : 'freshtv690)
    | MenhirState159 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv693 * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_ListItemExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv691 * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_ListItemExpr) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, (exp : 'tv_Expr)), _), _, (ls : 'tv_ListItemExpr)) = _menhir_stack in
        let _2 = () in
        let _v : 'tv_ListItemExpr = 
# 189 "parser.mly"
                                  ( exp::ls )
# 1670 "parser.ml"
         in
        _menhir_goto_ListItemExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv692)) : 'freshtv694)
    | _ ->
        _menhir_fail ()

and _menhir_run152 : _menhir_env -> (((((('ttv_tail * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | DFUN ->
        _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | EMPTYLIST ->
        _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | EQ ->
        _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | FALSE ->
        _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | FUN ->
        _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | GT ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | ID _v ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState152 _v
    | IF ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | INTV _v ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState152 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState152
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState152

and _menhir_run146 : _menhir_env -> (((('ttv_tail * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | DFUN ->
        _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | EMPTYLIST ->
        _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | EQ ->
        _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | FALSE ->
        _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | FUN ->
        _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | GT ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | ID _v ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState146 _v
    | IF ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | INTV _v ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState146 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState146
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState146

and _menhir_goto_LetAndExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_LetAndExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState9 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv669 * _menhir_state) * _menhir_state * 'tv_LetAndExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | IN ->
            _menhir_run127 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv667 * _menhir_state) * _menhir_state * 'tv_LetAndExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv668)) : 'freshtv670)
    | MenhirState133 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv673 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_LetAndExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv671 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_LetAndExpr) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s, (x : 'tv_IdWithTypeExpr)), _), _, (e : 'tv_Expr)), _), _, (ls : 'tv_LetAndExpr)) = _menhir_stack in
        let _4 = () in
        let _2 = () in
        let _v : 'tv_LetAndExpr = 
# 43 "parser.mly"
                                                 ( (x,e)::ls )
# 1804 "parser.ml"
         in
        _menhir_goto_LetAndExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv672)) : 'freshtv674)
    | MenhirState176 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv681 * _menhir_state) * _menhir_state * 'tv_LetAndExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | IN ->
            _menhir_run127 _menhir_env (Obj.magic _menhir_stack)
        | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv677 * _menhir_state) * _menhir_state * 'tv_LetAndExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv675 * _menhir_state) * _menhir_state * 'tv_LetAndExpr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s), _, (ls : 'tv_LetAndExpr)) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : (
# 21 "parser.mly"
      (Syntax.program)
# 1826 "parser.ml"
            ) = 
# 71 "parser.mly"
                             ( AndDecls ls )
# 1830 "parser.ml"
             in
            _menhir_goto_toplevel _menhir_env _menhir_stack _menhir_s _v) : 'freshtv676)) : 'freshtv678)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv679 * _menhir_state) * _menhir_state * 'tv_LetAndExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv680)) : 'freshtv682)
    | _ ->
        _menhir_fail ()

and _menhir_reduce60 : _menhir_env -> (('ttv_tail * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) * _menhir_state * 'tv_Expr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (((_menhir_stack, _menhir_s, (x : 'tv_IdWithTypeExpr)), _), _, (e : 'tv_Expr)) = _menhir_stack in
    let _2 = () in
    let _v : 'tv_LetAndExpr = 
# 44 "parser.mly"
                             ( [(x ,e)] )
# 1850 "parser.ml"
     in
    _menhir_goto_LetAndExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_run133 : _menhir_env -> (('ttv_tail * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) * _menhir_state * 'tv_Expr -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState133 _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState133

and _menhir_goto_LetExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_LetExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState99 | MenhirState97 | MenhirState95 | MenhirState49 | MenhirState52 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv661) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_LetExpr) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv659) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let ((e : 'tv_LetExpr) : 'tv_LetExpr) = _v in
        ((let _v : 'tv_AExprEx = 
# 157 "parser.mly"
           ( e )
# 1882 "parser.ml"
         in
        _menhir_goto_AExprEx _menhir_env _menhir_stack _menhir_s _v) : 'freshtv660)) : 'freshtv662)
    | MenhirState0 | MenhirState224 | MenhirState220 | MenhirState217 | MenhirState213 | MenhirState209 | MenhirState205 | MenhirState200 | MenhirState196 | MenhirState192 | MenhirState184 | MenhirState171 | MenhirState5 | MenhirState159 | MenhirState7 | MenhirState8 | MenhirState152 | MenhirState150 | MenhirState146 | MenhirState144 | MenhirState141 | MenhirState137 | MenhirState131 | MenhirState127 | MenhirState122 | MenhirState117 | MenhirState27 | MenhirState110 | MenhirState108 | MenhirState29 | MenhirState105 | MenhirState40 | MenhirState46 | MenhirState73 | MenhirState61 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv665) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_LetExpr) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv663) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let ((e : 'tv_LetExpr) : 'tv_LetExpr) = _v in
        ((let _v : 'tv_Expr = 
# 76 "parser.mly"
           ( e )
# 1897 "parser.ml"
         in
        _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv664)) : 'freshtv666)
    | _ ->
        _menhir_fail ()

and _menhir_reduce68 : _menhir_env -> ((('ttv_tail * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (((_menhir_stack, _menhir_s, (x : 'tv_IdWithTypeExpr)), _, (param : 'tv_IdWithTypeExpr)), _, (e : 'tv_Expr)) = _menhir_stack in
    let _3 = () in
    let _v : 'tv_LetRecAndExpr = 
# 52 "parser.mly"
                                                  ( [(x, param, e)] )
# 1910 "parser.ml"
     in
    _menhir_goto_LetRecAndExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_run124 : _menhir_env -> ((('ttv_tail * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState124 _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState124

and _menhir_reduce69 : _menhir_env -> ((((('ttv_tail * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let ((((_menhir_stack, _menhir_s, (x : 'tv_IdWithTypeExpr)), _), _, (param : 'tv_IdWithTypeExpr)), _, (e : 'tv_Expr)) = _menhir_stack in
    let _5 = () in
    let _3 = () in
    let _2 = () in
    let _v : 'tv_LetRecAndExpr = 
# 53 "parser.mly"
                                                             ( [(x, param, e)] )
# 1936 "parser.ml"
     in
    _menhir_goto_LetRecAndExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_run119 : _menhir_env -> ((((('ttv_tail * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState119 _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState119

and _menhir_goto_FunExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_FunExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState99 | MenhirState97 | MenhirState95 | MenhirState49 | MenhirState52 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv653) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_FunExpr) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv651) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let ((e : 'tv_FunExpr) : 'tv_FunExpr) = _v in
        ((let _v : 'tv_AExprEx = 
# 159 "parser.mly"
            ( e )
# 1968 "parser.ml"
         in
        _menhir_goto_AExprEx _menhir_env _menhir_stack _menhir_s _v) : 'freshtv652)) : 'freshtv654)
    | MenhirState0 | MenhirState224 | MenhirState220 | MenhirState217 | MenhirState213 | MenhirState209 | MenhirState205 | MenhirState200 | MenhirState196 | MenhirState192 | MenhirState184 | MenhirState171 | MenhirState5 | MenhirState159 | MenhirState7 | MenhirState8 | MenhirState152 | MenhirState150 | MenhirState146 | MenhirState144 | MenhirState141 | MenhirState137 | MenhirState131 | MenhirState127 | MenhirState122 | MenhirState117 | MenhirState27 | MenhirState110 | MenhirState108 | MenhirState29 | MenhirState105 | MenhirState40 | MenhirState46 | MenhirState73 | MenhirState61 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv657) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_FunExpr) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv655) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let ((e : 'tv_FunExpr) : 'tv_FunExpr) = _v in
        ((let _v : 'tv_Expr = 
# 83 "parser.mly"
            ( e )
# 1983 "parser.ml"
         in
        _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv656)) : 'freshtv658)
    | _ ->
        _menhir_fail ()

and _menhir_goto_AExprEx : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_AExprEx -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv649) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : 'tv_AExprEx) = _v in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv647) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((e : 'tv_AExprEx) : 'tv_AExprEx) = _v in
    ((let _v : 'tv_AppExpr = 
# 132 "parser.mly"
              ( e )
# 2002 "parser.ml"
     in
    _menhir_goto_AppExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv648)) : 'freshtv650)

and _menhir_run73 : _menhir_env -> 'ttv_tail * _menhir_state * 'tv_Expr -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | DFUN ->
        _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | EMPTYLIST ->
        _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | EQ ->
        _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | FALSE ->
        _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | FUN ->
        _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | GT ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | ID _v ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState73 _v
    | IF ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | INTV _v ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState73 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState73
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState73

and _menhir_reduce5 : _menhir_env -> ('ttv_tail * _menhir_state) * _menhir_state * 'tv_Expr -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _ ->
    let ((_menhir_stack, _menhir_s), _, (e : 'tv_Expr)) = _menhir_stack in
    let _3 = () in
    let _1 = () in
    let _v : 'tv_AExpr = 
# 147 "parser.mly"
                       ( e )
# 2063 "parser.ml"
     in
    _menhir_goto_AExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_run49 : _menhir_env -> 'ttv_tail * _menhir_state * 'tv_PExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DFUN ->
        _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState49
    | EMPTYLIST ->
        _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState49
    | FALSE ->
        _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState49
    | FUN ->
        _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState49
    | ID _v ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState49 _v
    | IF ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState49
    | INTV _v ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState49 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState49
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState49
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState49
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState49
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState49
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState49
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState49

and _menhir_run52 : _menhir_env -> 'ttv_tail * _menhir_state * 'tv_MExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DFUN ->
        _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState52
    | EMPTYLIST ->
        _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState52
    | FALSE ->
        _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState52
    | FUN ->
        _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState52
    | ID _v ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState52 _v
    | IF ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState52
    | INTV _v ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState52 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState52
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState52
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState52
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState52
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState52
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState52

and _menhir_goto_IdWithTypeExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_IdWithTypeExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState33 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv565 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv561 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | ID _v ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState35 _v
            | LPAREN ->
                _menhir_run33 _menhir_env (Obj.magic _menhir_stack) MenhirState35
            | COLON | EQ | RARROW ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv559 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr)) = Obj.magic _menhir_stack in
                ((let ((_menhir_stack, _menhir_s), _, (id_type : 'tv_IdWithTypeExpr)) = _menhir_stack in
                let _3 = () in
                let _1 = () in
                let _v : 'tv_FunParamListExpr = 
# 186 "parser.mly"
                                       ( [id_type] )
# 2166 "parser.ml"
                 in
                _menhir_goto_FunParamListExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv560)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState35) : 'freshtv562)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv563 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv564)) : 'freshtv566)
    | MenhirState124 | MenhirState119 | MenhirState10 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv573 * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv571 * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState113 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | FUN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv567 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) = Obj.magic _menhir_stack in
                ((let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | ID _v ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState115 _v
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState115) : 'freshtv568)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv569 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) = Obj.magic _menhir_stack in
                ((let (_menhir_stack, _menhir_s) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv570)) : 'freshtv572)
        | ID _v ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState113) : 'freshtv574)
    | MenhirState115 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv579 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RARROW ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv575 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState117 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState117 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState117
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState117) : 'freshtv576)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv577 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv578)) : 'freshtv580)
    | MenhirState113 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv585 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv581 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState122 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState122 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState122
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState122) : 'freshtv582)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv583 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv584)) : 'freshtv586)
    | MenhirState9 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv587 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            _menhir_run131 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | ID _v ->
            _menhir_run130 _menhir_env (Obj.magic _menhir_stack) MenhirState129 _v
        | LPAREN ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState129) : 'freshtv588)
    | MenhirState133 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv589 * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            _menhir_run131 _menhir_env (Obj.magic _menhir_stack) MenhirState135
        | ID _v ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState135 _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState135) : 'freshtv590)
    | MenhirState204 | MenhirState129 | MenhirState135 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv597 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | COLON ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv591 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState139
            | TYPE_BOOL ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState139
            | TYPE_ID _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState139 _v
            | TYPE_INT ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState139
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState139) : 'freshtv592)
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv593 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState137 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState137 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState137) : 'freshtv594)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv595 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv596)) : 'freshtv598)
    | MenhirState177 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv605 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv603 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState180 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | FUN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ((('freshtv599 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) = Obj.magic _menhir_stack in
                ((let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | ID _v ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState182 _v
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState182) : 'freshtv600)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ((('freshtv601 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) = Obj.magic _menhir_stack in
                ((let (_menhir_stack, _menhir_s) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv602)) : 'freshtv604)
        | ID _v ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState180 _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState180) : 'freshtv606)
    | MenhirState182 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv611 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RARROW ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv607 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState184 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState184 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState184) : 'freshtv608)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv609 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv610)) : 'freshtv612)
    | MenhirState187 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv619 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv617 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState188 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | FUN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ((('freshtv613 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) = Obj.magic _menhir_stack in
                ((let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | ID _v ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState190 _v
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState190) : 'freshtv614)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ((('freshtv615 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) = Obj.magic _menhir_stack in
                ((let (_menhir_stack, _menhir_s) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv616)) : 'freshtv618)
        | ID _v ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState188 _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState188) : 'freshtv620)
    | MenhirState190 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv625 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RARROW ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv621 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState192 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState192 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState192) : 'freshtv622)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv623 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv624)) : 'freshtv626)
    | MenhirState188 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv631 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv627 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState196 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState196 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState196) : 'freshtv628)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv629 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv630)) : 'freshtv632)
    | MenhirState180 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv637 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv633 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState200 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState200 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState200
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState200) : 'freshtv634)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv635 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv636)) : 'freshtv638)
    | MenhirState176 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv641 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv639 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState204 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState205 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState205 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState205
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState205) : 'freshtv640)
        | ID _v ->
            _menhir_run130 _menhir_env (Obj.magic _menhir_stack) MenhirState204 _v
        | LPAREN ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack) MenhirState204
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState204) : 'freshtv642)
    | MenhirState207 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv645 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv643 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState208 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState209 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState209 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState209
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState209) : 'freshtv644)
        | ID _v ->
            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState208 _v
        | LPAREN ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack) MenhirState208
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState208) : 'freshtv646)
    | _ ->
        _menhir_fail ()

and _menhir_run13 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv557) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_TypeAExpr = 
# 29 "parser.mly"
           ( TyInt )
# 2913 "parser.ml"
     in
    _menhir_goto_TypeAExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv558)

and _menhir_run14 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 18 "parser.mly"
       (Syntax.id)
# 2920 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv555) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((x : (
# 18 "parser.mly"
       (Syntax.id)
# 2930 "parser.ml"
    )) : (
# 18 "parser.mly"
       (Syntax.id)
# 2934 "parser.ml"
    )) = _v in
    ((let _v : 'tv_TypeAExpr = 
# 31 "parser.mly"
            ( TyVar (TyVarName x) )
# 2939 "parser.ml"
     in
    _menhir_goto_TypeAExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv556)

and _menhir_run15 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv553) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_TypeAExpr = 
# 30 "parser.mly"
            ( TyBool )
# 2953 "parser.ml"
     in
    _menhir_goto_TypeAExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv554)

and _menhir_run16 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LPAREN ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState16
    | TYPE_BOOL ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState16
    | TYPE_ID _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState16 _v
    | TYPE_INT ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState16
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState16

and _menhir_goto_FunParamListExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_FunParamListExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState130 | MenhirState36 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv515 * _menhir_state * (
# 17 "parser.mly"
       (Syntax.id)
# 2985 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv513 * _menhir_state * (
# 17 "parser.mly"
       (Syntax.id)
# 2991 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, (id : (
# 17 "parser.mly"
       (Syntax.id)
# 2996 "parser.ml"
        ))), _, (ls_param : 'tv_FunParamListExpr)) = _menhir_stack in
        let _v : 'tv_FunParamListExpr = 
# 183 "parser.mly"
                                  ( (id, TyNone) :: ls_param )
# 3001 "parser.ml"
         in
        _menhir_goto_FunParamListExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv514)) : 'freshtv516)
    | MenhirState35 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv519 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv517 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s), _, (id_type : 'tv_IdWithTypeExpr)), _, (ls_param : 'tv_FunParamListExpr)) = _menhir_stack in
        let _3 = () in
        let _1 = () in
        let _v : 'tv_FunParamListExpr = 
# 185 "parser.mly"
                                                                 ( id_type :: ls_param )
# 3015 "parser.ml"
         in
        _menhir_goto_FunParamListExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv518)) : 'freshtv520)
    | MenhirState32 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv527 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | COLON ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv521 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState103
            | TYPE_BOOL ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState103
            | TYPE_ID _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState103 _v
            | TYPE_INT ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState103
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState103) : 'freshtv522)
        | RARROW ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv523 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState40 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState40 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState40
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState40) : 'freshtv524)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv525 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv526)) : 'freshtv528)
    | MenhirState129 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv535 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | COLON ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv529 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState148
            | TYPE_BOOL ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState148
            | TYPE_ID _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState148 _v
            | TYPE_INT ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState148
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState148) : 'freshtv530)
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv531 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState144 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState144 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState144) : 'freshtv532)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv533 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv534)) : 'freshtv536)
    | MenhirState208 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv543 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | COLON ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv537 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState215
            | TYPE_BOOL ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState215
            | TYPE_ID _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState215 _v
            | TYPE_INT ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState215
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState215) : 'freshtv538)
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv539 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState213 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState213 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState213
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState213) : 'freshtv540)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv541 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv542)) : 'freshtv544)
    | MenhirState204 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv551 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | COLON ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv545 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState222
            | TYPE_BOOL ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState222
            | TYPE_ID _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState222 _v
            | TYPE_INT ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState222
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState222) : 'freshtv546)
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv547 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState220 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState220 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState220
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState220) : 'freshtv548)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv549 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv550)) : 'freshtv552)
    | _ ->
        _menhir_fail ()

and _menhir_goto_AExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_AExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState59 | MenhirState84 | MenhirState78 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv493 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EMPTYLIST ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | FALSE ->
            _menhir_run81 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | ID _v ->
            _menhir_run80 _menhir_env (Obj.magic _menhir_stack) MenhirState84 _v
        | INTV _v ->
            _menhir_run79 _menhir_env (Obj.magic _menhir_stack) MenhirState84 _v
        | LPAREN ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | LSQBRACKET ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | TRUE ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | ANDKW | ELSE | EQ | GT | IN | LET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv491 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, (e : 'tv_AExpr)) = _menhir_stack in
            let _v : 'tv_AppParamListExpr = 
# 140 "parser.mly"
            ( [e] )
# 3368 "parser.ml"
             in
            _menhir_goto_AppParamListExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv492)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState84) : 'freshtv494)
    | MenhirState0 | MenhirState224 | MenhirState220 | MenhirState205 | MenhirState217 | MenhirState213 | MenhirState209 | MenhirState200 | MenhirState184 | MenhirState196 | MenhirState192 | MenhirState5 | MenhirState171 | MenhirState7 | MenhirState159 | MenhirState8 | MenhirState150 | MenhirState152 | MenhirState144 | MenhirState146 | MenhirState131 | MenhirState141 | MenhirState137 | MenhirState127 | MenhirState122 | MenhirState117 | MenhirState27 | MenhirState29 | MenhirState108 | MenhirState110 | MenhirState105 | MenhirState40 | MenhirState46 | MenhirState61 | MenhirState73 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv501 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | AND ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv495 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState91
            | FALSE ->
                _menhir_run81 _menhir_env (Obj.magic _menhir_stack) MenhirState91
            | ID _v ->
                _menhir_run80 _menhir_env (Obj.magic _menhir_stack) MenhirState91 _v
            | INTV _v ->
                _menhir_run79 _menhir_env (Obj.magic _menhir_stack) MenhirState91 _v
            | LPAREN ->
                _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState91
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState91
            | TRUE ->
                _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState91
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState91) : 'freshtv496)
        | OR ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv497 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState89
            | FALSE ->
                _menhir_run81 _menhir_env (Obj.magic _menhir_stack) MenhirState89
            | ID _v ->
                _menhir_run80 _menhir_env (Obj.magic _menhir_stack) MenhirState89 _v
            | INTV _v ->
                _menhir_run79 _menhir_env (Obj.magic _menhir_stack) MenhirState89 _v
            | LPAREN ->
                _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState89
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState89
            | TRUE ->
                _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState89
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState89) : 'freshtv498)
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | TWOCOLONS | WITH ->
            _menhir_reduce22 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv499 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv500)) : 'freshtv502)
    | MenhirState89 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv505 * _menhir_state * 'tv_AExpr)) * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv503 * _menhir_state * 'tv_AExpr)) * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, (l : 'tv_AExpr)), _, (r : 'tv_AExpr)) = _menhir_stack in
        let _2 = () in
        let _v : 'tv_OrExpr = 
# 125 "parser.mly"
                       ( BinOp(Or, l, r) )
# 3448 "parser.ml"
         in
        _menhir_goto_OrExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv504)) : 'freshtv506)
    | MenhirState91 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv509 * _menhir_state * 'tv_AExpr)) * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv507 * _menhir_state * 'tv_AExpr)) * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, (l : 'tv_AExpr)), _, (r : 'tv_AExpr)) = _menhir_stack in
        let _2 = () in
        let _v : 'tv_AndExpr = 
# 121 "parser.mly"
                        ( BinOp(And, l, r) )
# 3461 "parser.ml"
         in
        _menhir_goto_AndExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv508)) : 'freshtv510)
    | MenhirState99 | MenhirState97 | MenhirState95 | MenhirState49 | MenhirState52 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv511 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        (_menhir_reduce22 _menhir_env (Obj.magic _menhir_stack) : 'freshtv512)
    | _ ->
        _menhir_fail ()

and _menhir_fail : unit -> 'a =
  fun () ->
    Printf.fprintf Pervasives.stderr "Internal failure -- please contact the parser generator's developers.\n%!";
    assert false

and _menhir_reduce6 : _menhir_env -> 'ttv_tail * _menhir_state * 'tv_ListExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (_menhir_stack, _menhir_s, (e : 'tv_ListExpr)) = _menhir_stack in
    let _v : 'tv_AExpr = 
# 148 "parser.mly"
             ( e )
# 3482 "parser.ml"
     in
    _menhir_goto_AExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_Expr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_Expr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState61 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv339 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv337 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState72 in
            ((let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce5 _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv338)
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState72
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState72) : 'freshtv340)
    | MenhirState73 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv349 * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState74
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv347 * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s, (e1 : 'tv_Expr)), _), _, (e2 : 'tv_Expr)) = _menhir_stack in
            let _2 = () in
            let _v : 'tv_AppendExpr = 
# 136 "parser.mly"
                              ( AppendExp(e1, e2) )
# 3524 "parser.ml"
             in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv345) = _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_AppendExpr) = _v in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv343) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_AppendExpr) = _v in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv341) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let ((e : 'tv_AppendExpr) : 'tv_AppendExpr) = _v in
            ((let _v : 'tv_Expr = 
# 85 "parser.mly"
               ( e )
# 3541 "parser.ml"
             in
            _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv342)) : 'freshtv344)) : 'freshtv346)) : 'freshtv348)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState74) : 'freshtv350)
    | MenhirState46 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv363 * _menhir_state) * (
# 17 "parser.mly"
       (Syntax.id)
# 3553 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState101
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv361 * _menhir_state) * (
# 17 "parser.mly"
       (Syntax.id)
# 3565 "parser.ml"
            ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s), (x : (
# 17 "parser.mly"
       (Syntax.id)
# 3570 "parser.ml"
            ))), _, (e : 'tv_Expr)) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_DFunExpr = 
# 180 "parser.mly"
                          ( DFunExp(x, e) )
# 3577 "parser.ml"
             in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv359) = _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_DFunExpr) = _v in
            ((match _menhir_s with
            | MenhirState99 | MenhirState97 | MenhirState95 | MenhirState49 | MenhirState52 ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv353) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let (_v : 'tv_DFunExpr) = _v in
                ((let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv351) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let ((e : 'tv_DFunExpr) : 'tv_DFunExpr) = _v in
                ((let _v : 'tv_AExprEx = 
# 160 "parser.mly"
             ( e )
# 3596 "parser.ml"
                 in
                _menhir_goto_AExprEx _menhir_env _menhir_stack _menhir_s _v) : 'freshtv352)) : 'freshtv354)
            | MenhirState0 | MenhirState224 | MenhirState220 | MenhirState205 | MenhirState217 | MenhirState213 | MenhirState209 | MenhirState200 | MenhirState184 | MenhirState196 | MenhirState192 | MenhirState5 | MenhirState171 | MenhirState7 | MenhirState159 | MenhirState8 | MenhirState150 | MenhirState152 | MenhirState144 | MenhirState146 | MenhirState131 | MenhirState141 | MenhirState137 | MenhirState127 | MenhirState122 | MenhirState117 | MenhirState27 | MenhirState29 | MenhirState108 | MenhirState110 | MenhirState105 | MenhirState40 | MenhirState46 | MenhirState61 | MenhirState73 ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv357) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let (_v : 'tv_DFunExpr) = _v in
                ((let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv355) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let ((e : 'tv_DFunExpr) : 'tv_DFunExpr) = _v in
                ((let _v : 'tv_Expr = 
# 84 "parser.mly"
             ( e )
# 3611 "parser.ml"
                 in
                _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv356)) : 'freshtv358)
            | _ ->
                _menhir_fail ()) : 'freshtv360)) : 'freshtv362)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState101) : 'freshtv364)
    | MenhirState40 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv367 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState102
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv365 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s), _, (ls_param : 'tv_FunParamListExpr)), _, (e : 'tv_Expr)) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_FunExpr = 
# 177 "parser.mly"
                                              ( FunExp(ls_param, TyNone, e) )
# 3637 "parser.ml"
             in
            _menhir_goto_FunExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv366)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState102) : 'freshtv368)
    | MenhirState105 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv371 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState106
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv369 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let ((((_menhir_stack, _menhir_s), _, (ls_param : 'tv_FunParamListExpr)), _, (t : 'tv_TypeExpr)), _, (e : 'tv_Expr)) = _menhir_stack in
            let _5 = () in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_FunExpr = 
# 176 "parser.mly"
                                                               ( FunExp(ls_param, t, e) )
# 3662 "parser.ml"
             in
            _menhir_goto_FunExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv370)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState106) : 'freshtv372)
    | MenhirState29 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv375 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | THEN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv373 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState107 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState108 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState108 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState108) : 'freshtv374)
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState107
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState107) : 'freshtv376)
    | MenhirState108 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv379 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ELSE ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv377 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState109 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState110 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState110 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState110
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState110) : 'freshtv378)
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState109
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState109) : 'freshtv380)
    | MenhirState110 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv393 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState111
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv391 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let ((((((_menhir_stack, _menhir_s), _, (c : 'tv_Expr)), _), _, (t : 'tv_Expr)), _), _, (e : 'tv_Expr)) = _menhir_stack in
            let _5 = () in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_IfExpr = 
# 165 "parser.mly"
                                      ( IfExp (c, t, e) )
# 3811 "parser.ml"
             in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv389) = _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_IfExpr) = _v in
            ((match _menhir_s with
            | MenhirState99 | MenhirState97 | MenhirState95 | MenhirState49 | MenhirState52 ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv383) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let (_v : 'tv_IfExpr) = _v in
                ((let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv381) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let ((e : 'tv_IfExpr) : 'tv_IfExpr) = _v in
                ((let _v : 'tv_AExprEx = 
# 156 "parser.mly"
           ( e )
# 3830 "parser.ml"
                 in
                _menhir_goto_AExprEx _menhir_env _menhir_stack _menhir_s _v) : 'freshtv382)) : 'freshtv384)
            | MenhirState0 | MenhirState224 | MenhirState220 | MenhirState217 | MenhirState213 | MenhirState209 | MenhirState205 | MenhirState200 | MenhirState196 | MenhirState192 | MenhirState184 | MenhirState171 | MenhirState5 | MenhirState159 | MenhirState7 | MenhirState8 | MenhirState152 | MenhirState150 | MenhirState146 | MenhirState144 | MenhirState141 | MenhirState137 | MenhirState131 | MenhirState127 | MenhirState122 | MenhirState117 | MenhirState27 | MenhirState110 | MenhirState108 | MenhirState29 | MenhirState105 | MenhirState40 | MenhirState46 | MenhirState73 | MenhirState61 ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv387) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let (_v : 'tv_IfExpr) = _v in
                ((let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv385) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let ((e : 'tv_IfExpr) : 'tv_IfExpr) = _v in
                ((let _v : 'tv_Expr = 
# 75 "parser.mly"
           ( e )
# 3845 "parser.ml"
                 in
                _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv386)) : 'freshtv388)
            | _ ->
                _menhir_fail ()) : 'freshtv390)) : 'freshtv392)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState111) : 'freshtv394)
    | MenhirState27 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv407 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState112
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((('freshtv405 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let ((((_menhir_stack, _menhir_s), _), _, (ls : 'tv_LetRecAndExpr)), _, (e : 'tv_Expr)) = _menhir_stack in
            let _4 = () in
            let _2 = () in
            let _1 = () in
            let _v : 'tv_LetRecExpr = 
# 173 "parser.mly"
                                     ( LetRecExp(ls, e) )
# 3872 "parser.ml"
             in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv403) = _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_LetRecExpr) = _v in
            ((match _menhir_s with
            | MenhirState99 | MenhirState97 | MenhirState95 | MenhirState49 | MenhirState52 ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv397) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let (_v : 'tv_LetRecExpr) = _v in
                ((let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv395) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let ((e : 'tv_LetRecExpr) : 'tv_LetRecExpr) = _v in
                ((let _v : 'tv_AExprEx = 
# 158 "parser.mly"
               ( e )
# 3891 "parser.ml"
                 in
                _menhir_goto_AExprEx _menhir_env _menhir_stack _menhir_s _v) : 'freshtv396)) : 'freshtv398)
            | MenhirState0 | MenhirState224 | MenhirState220 | MenhirState217 | MenhirState213 | MenhirState209 | MenhirState205 | MenhirState200 | MenhirState196 | MenhirState192 | MenhirState184 | MenhirState171 | MenhirState5 | MenhirState159 | MenhirState7 | MenhirState8 | MenhirState152 | MenhirState150 | MenhirState146 | MenhirState144 | MenhirState141 | MenhirState137 | MenhirState131 | MenhirState127 | MenhirState122 | MenhirState117 | MenhirState27 | MenhirState110 | MenhirState108 | MenhirState29 | MenhirState105 | MenhirState40 | MenhirState46 | MenhirState73 | MenhirState61 ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv401) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let (_v : 'tv_LetRecExpr) = _v in
                ((let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv399) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let ((e : 'tv_LetRecExpr) : 'tv_LetRecExpr) = _v in
                ((let _v : 'tv_Expr = 
# 77 "parser.mly"
               ( e )
# 3906 "parser.ml"
                 in
                _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv400)) : 'freshtv402)
            | _ ->
                _menhir_fail ()) : 'freshtv404)) : 'freshtv406)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState112) : 'freshtv408)
    | MenhirState117 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv409 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ANDKW ->
            _menhir_run119 _menhir_env (Obj.magic _menhir_stack) MenhirState118
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState118
        | IN | SEMISEMI ->
            _menhir_reduce69 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState118) : 'freshtv410)
    | MenhirState122 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv411 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ANDKW ->
            _menhir_run124 _menhir_env (Obj.magic _menhir_stack) MenhirState123
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState123
        | IN | SEMISEMI ->
            _menhir_reduce68 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState123) : 'freshtv412)
    | MenhirState127 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv415 * _menhir_state) * _menhir_state * 'tv_LetAndExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState128
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv413 * _menhir_state) * _menhir_state * 'tv_LetAndExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s), _, (ls : 'tv_LetAndExpr)), _, (e : 'tv_Expr)) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_LetExpr = 
# 168 "parser.mly"
                              ( LetExp(ls, e) )
# 3964 "parser.ml"
             in
            _menhir_goto_LetExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv414)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState128) : 'freshtv416)
    | MenhirState131 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv417 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ANDKW ->
            _menhir_run133 _menhir_env (Obj.magic _menhir_stack) MenhirState132
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState132
        | IN | SEMISEMI ->
            _menhir_reduce60 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState132) : 'freshtv418)
    | MenhirState137 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv421 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | IN | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv419 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s, (x : 'tv_IdWithTypeExpr)), _, (param : 'tv_IdWithTypeExpr)), _, (e : 'tv_Expr)) = _menhir_stack in
            let _3 = () in
            let _v : 'tv_LetAndExpr = 
# 45 "parser.mly"
                                                  ( [(x, FunExp([param], TyNone, e))] )
# 4003 "parser.ml"
             in
            _menhir_goto_LetAndExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv420)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState138) : 'freshtv422)
    | MenhirState141 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv425 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState142
        | IN | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv423 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let ((((_menhir_stack, _menhir_s, (x : 'tv_IdWithTypeExpr)), _, (param : 'tv_IdWithTypeExpr)), _, (t : 'tv_TypeExpr)), _, (e : 'tv_Expr)) = _menhir_stack in
            let _5 = () in
            let _3 = () in
            let _v : 'tv_LetAndExpr = 
# 46 "parser.mly"
                                                                   ( [(x, FunExp([param], t, e))] )
# 4027 "parser.ml"
             in
            _menhir_goto_LetAndExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv424)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState142) : 'freshtv426)
    | MenhirState144 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv427 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | IN ->
            _menhir_run146 _menhir_env (Obj.magic _menhir_stack) MenhirState145
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState145
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState145) : 'freshtv428)
    | MenhirState146 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv431 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState147
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((((('freshtv429 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let ((((((_menhir_stack, _menhir_s), _, (x : 'tv_IdWithTypeExpr)), _, (ls_param : 'tv_FunParamListExpr)), _, (e : 'tv_Expr)), _), _, (e2 : 'tv_Expr)) = _menhir_stack in
            let _6 = () in
            let _4 = () in
            let _1 = () in
            let _v : 'tv_LetExpr = 
# 169 "parser.mly"
                                                                      ( LetExp([(x, FunExp(ls_param, TyNone, e))], e2) )
# 4066 "parser.ml"
             in
            _menhir_goto_LetExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv430)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState147) : 'freshtv432)
    | MenhirState150 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv433 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | IN ->
            _menhir_run152 _menhir_env (Obj.magic _menhir_stack) MenhirState151
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState151
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState151) : 'freshtv434)
    | MenhirState152 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((((('freshtv437 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState153
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((((((('freshtv435 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let (((((((_menhir_stack, _menhir_s), _, (x : 'tv_IdWithTypeExpr)), _, (ls_param : 'tv_FunParamListExpr)), _, (t : 'tv_TypeExpr)), _, (e : 'tv_Expr)), _), _, (e2 : 'tv_Expr)) = _menhir_stack in
            let _8 = () in
            let _6 = () in
            let _4 = () in
            let _1 = () in
            let _v : 'tv_LetExpr = 
# 170 "parser.mly"
                                                                                       ( LetExp([(x, FunExp(ls_param, t, e))], e2) )
# 4106 "parser.ml"
             in
            _menhir_goto_LetExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv436)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState153) : 'freshtv438)
    | MenhirState8 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv441 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv439 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState154 in
            ((let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce5 _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv440)
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState154
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState154) : 'freshtv442)
    | MenhirState159 | MenhirState7 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv447 * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | SEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv443 * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState158 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState159 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState159 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState159
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState159) : 'freshtv444)
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState158
        | RSQBRACKET ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv445 * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, (exp : 'tv_Expr)) = _menhir_stack in
            let _v : 'tv_ListItemExpr = 
# 190 "parser.mly"
             ( [exp] )
# 4196 "parser.ml"
             in
            _menhir_goto_ListItemExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv446)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState158) : 'freshtv448)
    | MenhirState5 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv451 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState161
        | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv449 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState161 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | EMPTYLIST ->
                _menhir_run169 _menhir_env (Obj.magic _menhir_stack) MenhirState162
            | ID _v ->
                _menhir_run166 _menhir_env (Obj.magic _menhir_stack) MenhirState162 _v
            | LSQBRACKET ->
                _menhir_run163 _menhir_env (Obj.magic _menhir_stack) MenhirState162
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState162) : 'freshtv450)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState161) : 'freshtv452)
    | MenhirState171 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv457 * _menhir_state * 'tv_MatchPatternExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | SEP ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv453 * _menhir_state * 'tv_MatchPatternExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState172 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | EMPTYLIST ->
                _menhir_run169 _menhir_env (Obj.magic _menhir_stack) MenhirState173
            | ID _v ->
                _menhir_run166 _menhir_env (Obj.magic _menhir_stack) MenhirState173 _v
            | LSQBRACKET ->
                _menhir_run163 _menhir_env (Obj.magic _menhir_stack) MenhirState173
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState173) : 'freshtv454)
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState172
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv455 * _menhir_state * 'tv_MatchPatternExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, (match_pattern : 'tv_MatchPatternExpr)), _, (exp : 'tv_Expr)) = _menhir_stack in
            let _2 = () in
            let _v : 'tv_MatchListExprs = 
# 203 "parser.mly"
                                                   ( [(match_pattern, exp)] )
# 4267 "parser.ml"
             in
            _menhir_goto_MatchListExprs _menhir_env _menhir_stack _menhir_s _v) : 'freshtv456)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState172) : 'freshtv458)
    | MenhirState184 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv459 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ANDKW ->
            _menhir_run119 _menhir_env (Obj.magic _menhir_stack) MenhirState185
        | LET ->
            _menhir_run186 _menhir_env (Obj.magic _menhir_stack) MenhirState185
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState185
        | IN | SEMISEMI ->
            _menhir_reduce69 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState185) : 'freshtv460)
    | MenhirState192 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv463 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LET ->
            _menhir_run186 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((((('freshtv461 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let ((((((_menhir_stack, _menhir_s), _), _, (x : 'tv_IdWithTypeExpr)), _), _, (param : 'tv_IdWithTypeExpr)), _, (e : 'tv_Expr)) = _menhir_stack in
            let _7 = () in
            let _5 = () in
            let _4 = () in
            let _2 = () in
            let _1 = () in
            let _v : 'tv_TopLetRecExpr = 
# 65 "parser.mly"
                                                                     ( [(x, param, e)] )
# 4314 "parser.ml"
             in
            _menhir_goto_TopLetRecExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv462)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState193) : 'freshtv464)
    | MenhirState196 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv467 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LET ->
            _menhir_run186 _menhir_env (Obj.magic _menhir_stack) MenhirState197
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState197
        | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv465 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let (((((_menhir_stack, _menhir_s), _), _, (x : 'tv_IdWithTypeExpr)), _, (param : 'tv_IdWithTypeExpr)), _, (e : 'tv_Expr)) = _menhir_stack in
            let _5 = () in
            let _2 = () in
            let _1 = () in
            let _v : 'tv_TopLetRecExpr = 
# 64 "parser.mly"
                                                          ( [(x, param, e)] )
# 4341 "parser.ml"
             in
            _menhir_goto_TopLetRecExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv466)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState197) : 'freshtv468)
    | MenhirState200 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv469 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ANDKW ->
            _menhir_run124 _menhir_env (Obj.magic _menhir_stack) MenhirState201
        | LET ->
            _menhir_run186 _menhir_env (Obj.magic _menhir_stack) MenhirState201
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState201
        | IN | SEMISEMI ->
            _menhir_reduce68 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState201) : 'freshtv470)
    | MenhirState205 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv471 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ANDKW ->
            _menhir_run133 _menhir_env (Obj.magic _menhir_stack) MenhirState206
        | LET ->
            _menhir_run207 _menhir_env (Obj.magic _menhir_stack) MenhirState206
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState206
        | IN | SEMISEMI ->
            _menhir_reduce60 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState206) : 'freshtv472)
    | MenhirState209 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv475 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LET ->
            _menhir_run207 _menhir_env (Obj.magic _menhir_stack) MenhirState210
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState210
        | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv473 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let ((((_menhir_stack, _menhir_s), _, (x : 'tv_IdWithTypeExpr)), _), _, (e : 'tv_Expr)) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_TopLetExpr = 
# 57 "parser.mly"
                                 ( [(x, e)] )
# 4403 "parser.ml"
             in
            _menhir_goto_TopLetExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv474)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState210) : 'freshtv476)
    | MenhirState213 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv477 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState214
        | SEMISEMI ->
            _menhir_reduce91 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState214) : 'freshtv478)
    | MenhirState217 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv479 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState218
        | SEMISEMI ->
            _menhir_reduce92 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState218) : 'freshtv480)
    | MenhirState220 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv481 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | IN ->
            _menhir_run146 _menhir_env (Obj.magic _menhir_stack) MenhirState221
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState221
        | SEMISEMI ->
            _menhir_reduce91 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState221) : 'freshtv482)
    | MenhirState224 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv483 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | IN ->
            _menhir_run152 _menhir_env (Obj.magic _menhir_stack) MenhirState225
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState225
        | SEMISEMI ->
            _menhir_reduce92 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState225) : 'freshtv484)
    | MenhirState0 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv489 * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv487 * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState231 in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv485 * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_ : _menhir_state) = _menhir_s in
            ((let (_menhir_stack, _menhir_s, (e : 'tv_Expr)) = _menhir_stack in
            let _2 = () in
            let _v : (
# 21 "parser.mly"
      (Syntax.program)
# 4488 "parser.ml"
            ) = 
# 68 "parser.mly"
                  ( Exp e )
# 4492 "parser.ml"
             in
            _menhir_goto_toplevel _menhir_env _menhir_stack _menhir_s _v) : 'freshtv486)) : 'freshtv488)
        | TWOCOLONS ->
            _menhir_run73 _menhir_env (Obj.magic _menhir_stack) MenhirState231
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState231) : 'freshtv490)
    | _ ->
        _menhir_fail ()

and _menhir_reduce2 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _1 = () in
    let _v : 'tv_AExpr = 
# 144 "parser.mly"
         ( BLit true )
# 4510 "parser.ml"
     in
    _menhir_goto_AExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_PExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_PExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState0 | MenhirState224 | MenhirState220 | MenhirState217 | MenhirState213 | MenhirState209 | MenhirState205 | MenhirState200 | MenhirState196 | MenhirState192 | MenhirState184 | MenhirState171 | MenhirState5 | MenhirState159 | MenhirState7 | MenhirState8 | MenhirState152 | MenhirState150 | MenhirState146 | MenhirState144 | MenhirState141 | MenhirState137 | MenhirState131 | MenhirState127 | MenhirState122 | MenhirState117 | MenhirState27 | MenhirState110 | MenhirState108 | MenhirState29 | MenhirState105 | MenhirState40 | MenhirState73 | MenhirState61 | MenhirState46 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv317 * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv307 * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState99
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState99
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState99
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState99
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState99 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState99
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState99 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState99
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState99
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState99
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState99
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState99
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState99
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState99
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState99) : 'freshtv308)
        | GT ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv309 * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState97 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState97 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState97) : 'freshtv310)
        | LT ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv311 * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState95
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState95
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState95
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState95
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState95 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState95
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState95 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState95
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState95
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState95
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState95
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState95
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState95
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState95
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState95) : 'freshtv312)
        | PLUS ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack)
        | ANDKW | ELSE | EMPTYLIST | FALSE | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | MULT | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv313 * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, (e : 'tv_PExpr)) = _menhir_stack in
            let _v : 'tv_EQExpr = 
# 102 "parser.mly"
            ( e )
# 4647 "parser.ml"
             in
            _menhir_goto_EQExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv314)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv315 * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv316)) : 'freshtv318)
    | MenhirState95 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv323 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | PLUS ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack)
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv319 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, (l : 'tv_PExpr)), _, (r : 'tv_PExpr)) = _menhir_stack in
            let _2 = () in
            let _v : 'tv_LTExpr = 
# 90 "parser.mly"
                       ( BinOp (Lt, l, r) )
# 4673 "parser.ml"
             in
            _menhir_goto_LTExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv320)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv321 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv322)) : 'freshtv324)
    | MenhirState97 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv329 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | PLUS ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack)
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv325 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, (l : 'tv_PExpr)), _, (r : 'tv_PExpr)) = _menhir_stack in
            let _2 = () in
            let _v : 'tv_GTExpr = 
# 95 "parser.mly"
                       ( BinOp (Gt, l, r) )
# 4699 "parser.ml"
             in
            _menhir_goto_GTExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv326)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv327 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv328)) : 'freshtv330)
    | MenhirState99 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv335 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | PLUS ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack)
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv331 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, (l : 'tv_PExpr)), _, (r : 'tv_PExpr)) = _menhir_stack in
            let _2 = () in
            let _v : 'tv_EQExpr = 
# 100 "parser.mly"
                       ( BinOp (Eq, l, r) )
# 4725 "parser.ml"
             in
            _menhir_goto_EQExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv332)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv333 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv334)) : 'freshtv336)
    | _ ->
        _menhir_fail ()

and _menhir_goto_OrExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_OrExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv305) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : 'tv_OrExpr) = _v in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv303) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((e : 'tv_OrExpr) : 'tv_OrExpr) = _v in
    ((let _v : 'tv_Expr = 
# 82 "parser.mly"
           ( e )
# 4751 "parser.ml"
     in
    _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv304)) : 'freshtv306)

and _menhir_goto_MExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_MExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState49 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv295 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_MExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | MULT ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack)
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv291 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_MExpr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, (l : 'tv_PExpr)), _, (r : 'tv_MExpr)) = _menhir_stack in
            let _2 = () in
            let _v : 'tv_PExpr = 
# 105 "parser.mly"
                         ( BinOp (Plus, l, r) )
# 4775 "parser.ml"
             in
            _menhir_goto_PExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv292)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv293 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_MExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv294)) : 'freshtv296)
    | MenhirState0 | MenhirState224 | MenhirState220 | MenhirState217 | MenhirState213 | MenhirState209 | MenhirState205 | MenhirState200 | MenhirState196 | MenhirState192 | MenhirState184 | MenhirState171 | MenhirState5 | MenhirState159 | MenhirState7 | MenhirState8 | MenhirState152 | MenhirState150 | MenhirState146 | MenhirState144 | MenhirState141 | MenhirState137 | MenhirState131 | MenhirState127 | MenhirState122 | MenhirState117 | MenhirState27 | MenhirState110 | MenhirState108 | MenhirState29 | MenhirState105 | MenhirState40 | MenhirState46 | MenhirState99 | MenhirState97 | MenhirState95 | MenhirState73 | MenhirState61 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv301 * _menhir_state * 'tv_MExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | MULT ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack)
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv297 * _menhir_state * 'tv_MExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, (e : 'tv_MExpr)) = _menhir_stack in
            let _v : 'tv_PExpr = 
# 107 "parser.mly"
            ( e )
# 4800 "parser.ml"
             in
            _menhir_goto_PExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv298)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv299 * _menhir_state * 'tv_MExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv300)) : 'freshtv302)
    | _ ->
        _menhir_fail ()

and _menhir_goto_LTExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_LTExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv289) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : 'tv_LTExpr) = _v in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv287) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((e : 'tv_LTExpr) : 'tv_LTExpr) = _v in
    ((let _v : 'tv_Expr = 
# 78 "parser.mly"
           ( e )
# 4826 "parser.ml"
     in
    _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv288)) : 'freshtv290)

and _menhir_reduce54 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 17 "parser.mly"
       (Syntax.id)
# 4833 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (_menhir_stack, _menhir_s, (x : (
# 17 "parser.mly"
       (Syntax.id)
# 4839 "parser.ml"
    ))) = _menhir_stack in
    let _v : 'tv_IdWithTypeExpr = 
# 26 "parser.mly"
       ( (x, TyNone) )
# 4844 "parser.ml"
     in
    _menhir_goto_IdWithTypeExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_run12 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 17 "parser.mly"
       (Syntax.id)
# 4851 "parser.ml"
) -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LPAREN ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState12
    | TYPE_BOOL ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState12
    | TYPE_ID _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _v
    | TYPE_INT ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState12
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState12

and _menhir_reduce1 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 16 "parser.mly"
       (int)
# 4874 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s (i : (
# 16 "parser.mly"
       (int)
# 4879 "parser.ml"
  )) ->
    let _v : 'tv_AExpr = 
# 143 "parser.mly"
         ( ILit i )
# 4884 "parser.ml"
     in
    _menhir_goto_AExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce4 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 17 "parser.mly"
       (Syntax.id)
# 4891 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s (i : (
# 17 "parser.mly"
       (Syntax.id)
# 4896 "parser.ml"
  )) ->
    let _v : 'tv_AExpr = 
# 146 "parser.mly"
         ( Var i )
# 4901 "parser.ml"
     in
    _menhir_goto_AExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_GTExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_GTExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv285) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : 'tv_GTExpr) = _v in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv283) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((e : 'tv_GTExpr) : 'tv_GTExpr) = _v in
    ((let _v : 'tv_Expr = 
# 79 "parser.mly"
           ( e )
# 4918 "parser.ml"
     in
    _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv284)) : 'freshtv286)

and _menhir_run33 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState33 _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState33

and _menhir_run36 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 17 "parser.mly"
       (Syntax.id)
# 4938 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _v
    | LPAREN ->
        _menhir_run33 _menhir_env (Obj.magic _menhir_stack) MenhirState36
    | COLON | EQ | RARROW ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv281 * _menhir_state * (
# 17 "parser.mly"
       (Syntax.id)
# 4954 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, (id : (
# 17 "parser.mly"
       (Syntax.id)
# 4959 "parser.ml"
        ))) = _menhir_stack in
        let _v : 'tv_FunParamListExpr = 
# 184 "parser.mly"
        ( [(id, TyNone)] )
# 4964 "parser.ml"
         in
        _menhir_goto_FunParamListExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv282)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState36

and _menhir_reduce3 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _1 = () in
    let _v : 'tv_AExpr = 
# 145 "parser.mly"
         ( BLit false )
# 4978 "parser.ml"
     in
    _menhir_goto_AExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_EQExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_EQExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv279) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : 'tv_EQExpr) = _v in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv277) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((e : 'tv_EQExpr) : 'tv_EQExpr) = _v in
    ((let _v : 'tv_Expr = 
# 80 "parser.mly"
           ( e )
# 4995 "parser.ml"
     in
    _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv278)) : 'freshtv280)

and _menhir_goto_ListExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_ListExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState99 | MenhirState97 | MenhirState95 | MenhirState49 | MenhirState52 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv267 * _menhir_state * 'tv_ListExpr) = Obj.magic _menhir_stack in
        (_menhir_reduce6 _menhir_env (Obj.magic _menhir_stack) : 'freshtv268)
    | MenhirState0 | MenhirState224 | MenhirState220 | MenhirState217 | MenhirState213 | MenhirState209 | MenhirState205 | MenhirState200 | MenhirState196 | MenhirState192 | MenhirState184 | MenhirState171 | MenhirState5 | MenhirState159 | MenhirState7 | MenhirState8 | MenhirState152 | MenhirState150 | MenhirState146 | MenhirState144 | MenhirState141 | MenhirState137 | MenhirState131 | MenhirState127 | MenhirState122 | MenhirState117 | MenhirState27 | MenhirState110 | MenhirState108 | MenhirState29 | MenhirState105 | MenhirState40 | MenhirState46 | MenhirState73 | MenhirState61 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv273 * _menhir_state * 'tv_ListExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv269 * _menhir_state * 'tv_ListExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, (e : 'tv_ListExpr)) = _menhir_stack in
            let _v : 'tv_Expr = 
# 86 "parser.mly"
             ( e )
# 5020 "parser.ml"
             in
            _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv270)
        | AND | OR ->
            _menhir_reduce6 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv271 * _menhir_state * 'tv_ListExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv272)) : 'freshtv274)
    | MenhirState59 | MenhirState91 | MenhirState89 | MenhirState84 | MenhirState78 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv275 * _menhir_state * 'tv_ListExpr) = Obj.magic _menhir_stack in
        (_menhir_reduce6 _menhir_env (Obj.magic _menhir_stack) : 'freshtv276)
    | _ ->
        _menhir_fail ()

and _menhir_run9 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState9 _v
    | REC ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv265 * _menhir_state) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState9 in
        ((let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ID _v ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState10) : 'freshtv266)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState9

and _menhir_goto_AndExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_AndExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv263) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : 'tv_AndExpr) = _v in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv261) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((e : 'tv_AndExpr) : 'tv_AndExpr) = _v in
    ((let _v : 'tv_Expr = 
# 81 "parser.mly"
            ( e )
# 5079 "parser.ml"
     in
    _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv262)) : 'freshtv264)

and _menhir_run1 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce2 _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run2 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv259) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_PExpr = 
# 106 "parser.mly"
         ( OpFunExp (Plus) )
# 5098 "parser.ml"
     in
    _menhir_goto_PExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv260)

and _menhir_run3 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv257) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_OrExpr = 
# 126 "parser.mly"
       ( OpFunExp (Or) )
# 5112 "parser.ml"
     in
    _menhir_goto_OrExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv258)

and _menhir_run4 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv255) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_MExpr = 
# 116 "parser.mly"
         ( OpFunExp (Mult) )
# 5126 "parser.ml"
     in
    _menhir_goto_MExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv256)

and _menhir_run5 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | DFUN ->
        _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | EMPTYLIST ->
        _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | EQ ->
        _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | FALSE ->
        _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | FUN ->
        _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | GT ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | ID _v ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState5 _v
    | IF ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | INTV _v ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState5 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState5

and _menhir_run6 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv253) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_LTExpr = 
# 91 "parser.mly"
       ( OpFunExp (Lt) )
# 5189 "parser.ml"
     in
    _menhir_goto_LTExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv254)

and _menhir_run7 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | DFUN ->
        _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | EMPTYLIST ->
        _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | EQ ->
        _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | FALSE ->
        _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | FUN ->
        _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | GT ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | ID _v ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState7 _v
    | IF ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | INTV _v ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState7 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState7

and _menhir_run8 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | DFUN ->
        _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | EMPTYLIST ->
        _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | EQ ->
        _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | FALSE ->
        _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | FUN ->
        _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | GT ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | ID _v ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _v
    | IF ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | INTV _v ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState8

and _menhir_errorcase : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    match _menhir_s with
    | MenhirState231 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv23 * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv24)
    | MenhirState225 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv25 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv26)
    | MenhirState224 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv27 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv28)
    | MenhirState222 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv29 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv30)
    | MenhirState221 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv31 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv32)
    | MenhirState220 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv33 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv34)
    | MenhirState218 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv35 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv36)
    | MenhirState217 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv37 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv38)
    | MenhirState215 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv39 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv40)
    | MenhirState214 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv41 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv42)
    | MenhirState213 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv43 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv44)
    | MenhirState210 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv45 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv46)
    | MenhirState209 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv47 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv48)
    | MenhirState208 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv49 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv50)
    | MenhirState207 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv51 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv52)
    | MenhirState206 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv53 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv54)
    | MenhirState205 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv55 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv56)
    | MenhirState204 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv57 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv58)
    | MenhirState201 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv59 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv60)
    | MenhirState200 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv61 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv62)
    | MenhirState197 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv63 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv64)
    | MenhirState196 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv65 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv66)
    | MenhirState193 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv67 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv68)
    | MenhirState192 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv69 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv70)
    | MenhirState190 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv71 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv72)
    | MenhirState188 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv73 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv74)
    | MenhirState187 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv75 * _menhir_state) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv76)
    | MenhirState186 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv77 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv78)
    | MenhirState185 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv79 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv80)
    | MenhirState184 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv81 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv82)
    | MenhirState182 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv83 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv84)
    | MenhirState180 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv85 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv86)
    | MenhirState177 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv87 * _menhir_state) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv88)
    | MenhirState176 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv89 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv90)
    | MenhirState173 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv91 * _menhir_state * 'tv_MatchPatternExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv92)
    | MenhirState172 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv93 * _menhir_state * 'tv_MatchPatternExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv94)
    | MenhirState171 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv95 * _menhir_state * 'tv_MatchPatternExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv96)
    | MenhirState162 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv97 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv98)
    | MenhirState161 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv99 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv100)
    | MenhirState159 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv101 * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv102)
    | MenhirState158 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv103 * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv104)
    | MenhirState154 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv105 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv106)
    | MenhirState153 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((((('freshtv107 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv108)
    | MenhirState152 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv109 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv110)
    | MenhirState151 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv111 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv112)
    | MenhirState150 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv113 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv114)
    | MenhirState148 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv115 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv116)
    | MenhirState147 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv117 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv118)
    | MenhirState146 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv119 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv120)
    | MenhirState145 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv121 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv122)
    | MenhirState144 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv123 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_FunParamListExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv124)
    | MenhirState142 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv125 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv126)
    | MenhirState141 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv127 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_TypeExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv128)
    | MenhirState139 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv129 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv130)
    | MenhirState138 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv131 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv132)
    | MenhirState137 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv133 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv134)
    | MenhirState135 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv135 * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv136)
    | MenhirState133 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv137 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv138)
    | MenhirState132 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv139 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv140)
    | MenhirState131 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv141 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv142)
    | MenhirState130 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv143 * _menhir_state * (
# 17 "parser.mly"
       (Syntax.id)
# 5599 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv144)
    | MenhirState129 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv145 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv146)
    | MenhirState128 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv147 * _menhir_state) * _menhir_state * 'tv_LetAndExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv148)
    | MenhirState127 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv149 * _menhir_state) * _menhir_state * 'tv_LetAndExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv150)
    | MenhirState124 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv151 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv152)
    | MenhirState123 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv153 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv154)
    | MenhirState122 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv155 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state * 'tv_IdWithTypeExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv156)
    | MenhirState119 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv157 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv158)
    | MenhirState118 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv159 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv160)
    | MenhirState117 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv161 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) * _menhir_state * 'tv_IdWithTypeExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv162)
    | MenhirState115 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv163 * _menhir_state * 'tv_IdWithTypeExpr) * _menhir_state)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv164)
    | MenhirState113 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv165 * _menhir_state * 'tv_IdWithTypeExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv166)
    | MenhirState112 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv167 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv168)
    | MenhirState111 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv169 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv170)
    | MenhirState110 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv171 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv172)
    | MenhirState109 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv173 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv174)
    | MenhirState108 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv175 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv176)
    | MenhirState107 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv177 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv178)
    | MenhirState106 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv179 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv180)
    | MenhirState105 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv181 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_TypeExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv182)
    | MenhirState103 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv183 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv184)
    | MenhirState102 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv185 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv186)
    | MenhirState101 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv187 * _menhir_state) * (
# 17 "parser.mly"
       (Syntax.id)
# 5713 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv188)
    | MenhirState99 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv189 * _menhir_state * 'tv_PExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv190)
    | MenhirState97 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv191 * _menhir_state * 'tv_PExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv192)
    | MenhirState95 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv193 * _menhir_state * 'tv_PExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv194)
    | MenhirState91 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv195 * _menhir_state * 'tv_AExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv196)
    | MenhirState89 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv197 * _menhir_state * 'tv_AExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv198)
    | MenhirState84 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv199 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv200)
    | MenhirState78 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv201 * _menhir_state * 'tv_AppExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv202)
    | MenhirState74 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv203 * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv204)
    | MenhirState73 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv205 * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv206)
    | MenhirState72 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv207 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv208)
    | MenhirState61 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv209 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv210)
    | MenhirState59 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv211 * _menhir_state * 'tv_MExpr)) * _menhir_state * 'tv_AppExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv212)
    | MenhirState52 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv213 * _menhir_state * 'tv_MExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv214)
    | MenhirState49 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv215 * _menhir_state * 'tv_PExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv216)
    | MenhirState46 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv217 * _menhir_state) * (
# 17 "parser.mly"
       (Syntax.id)
# 5792 "parser.ml"
        ))) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv218)
    | MenhirState40 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv219 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv220)
    | MenhirState36 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv221 * _menhir_state * (
# 17 "parser.mly"
       (Syntax.id)
# 5806 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv222)
    | MenhirState35 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv223 * _menhir_state) * _menhir_state * 'tv_IdWithTypeExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv224)
    | MenhirState33 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv225 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv226)
    | MenhirState32 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv227 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv228)
    | MenhirState29 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv229 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv230)
    | MenhirState27 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv231 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv232)
    | MenhirState22 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv233 * _menhir_state * 'tv_TypeAExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv234)
    | MenhirState16 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv235 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv236)
    | MenhirState12 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv237 * _menhir_state * (
# 17 "parser.mly"
       (Syntax.id)
# 5850 "parser.ml"
        )) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv238)
    | MenhirState11 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv239 * _menhir_state * (
# 17 "parser.mly"
       (Syntax.id)
# 5859 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv240)
    | MenhirState10 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv241 * _menhir_state) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv242)
    | MenhirState9 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv243 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv244)
    | MenhirState8 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv245 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv246)
    | MenhirState7 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv247 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv248)
    | MenhirState5 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv249 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv250)
    | MenhirState0 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv251) = Obj.magic _menhir_stack in
        (raise _eRR : 'freshtv252)

and _menhir_run11 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 17 "parser.mly"
       (Syntax.id)
# 5896 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | COLON ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState11
    | EQ | ID _ | LPAREN | RARROW | RPAREN ->
        _menhir_reduce54 _menhir_env (Obj.magic _menhir_stack)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState11

and _menhir_run28 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 16 "parser.mly"
       (int)
# 5915 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce1 _menhir_env (Obj.magic _menhir_stack) _menhir_s _v

and _menhir_run29 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | DFUN ->
        _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | EMPTYLIST ->
        _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | EQ ->
        _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | FALSE ->
        _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | FUN ->
        _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | GT ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | ID _v ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState29 _v
    | IF ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | INTV _v ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState29 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState29

and _menhir_run30 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 17 "parser.mly"
       (Syntax.id)
# 5973 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce4 _menhir_env (Obj.magic _menhir_stack) _menhir_s _v

and _menhir_run31 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv21) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_GTExpr = 
# 96 "parser.mly"
       ( OpFunExp (Gt) )
# 5989 "parser.ml"
     in
    _menhir_goto_GTExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv22)

and _menhir_run32 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState32 _v
    | LPAREN ->
        _menhir_run33 _menhir_env (Obj.magic _menhir_stack) MenhirState32
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState32

and _menhir_run41 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce3 _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run42 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv19) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_EQExpr = 
# 101 "parser.mly"
       ( OpFunExp (Eq) )
# 6023 "parser.ml"
     in
    _menhir_goto_EQExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv20)

and _menhir_run43 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv17) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_ListExpr = 
# 194 "parser.mly"
              ( ListExp ([]) )
# 6037 "parser.ml"
     in
    _menhir_goto_ListExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv18)

and _menhir_run44 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv13 * _menhir_state) = Obj.magic _menhir_stack in
        let (_v : (
# 17 "parser.mly"
       (Syntax.id)
# 6053 "parser.ml"
        )) = _v in
        ((let _menhir_stack = (_menhir_stack, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RARROW ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv9 * _menhir_state) * (
# 17 "parser.mly"
       (Syntax.id)
# 6064 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | DFUN ->
                _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | EMPTYLIST ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | EQ ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | FALSE ->
                _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | FUN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | GT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | ID _v ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState46 _v
            | IF ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | INTV _v ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState46 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState46
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState46) : 'freshtv10)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv11 * _menhir_state) * (
# 17 "parser.mly"
       (Syntax.id)
# 6118 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv12)) : 'freshtv14)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv15 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv16)

and _menhir_run47 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv7) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_AndExpr = 
# 122 "parser.mly"
        ( OpFunExp (And) )
# 6140 "parser.ml"
     in
    _menhir_goto_AndExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv8)

and _menhir_discard : _menhir_env -> _menhir_env =
  fun _menhir_env ->
    let lexer = _menhir_env._menhir_lexer in
    let lexbuf = _menhir_env._menhir_lexbuf in
    let _tok = lexer lexbuf in
    {
      _menhir_lexer = lexer;
      _menhir_lexbuf = lexbuf;
      _menhir_token = _tok;
      _menhir_error = false;
    }

and toplevel : (Lexing.lexbuf -> token) -> Lexing.lexbuf -> (
# 21 "parser.mly"
      (Syntax.program)
# 6159 "parser.ml"
) =
  fun lexer lexbuf ->
    let _menhir_env =
      let (lexer : Lexing.lexbuf -> token) = lexer in
      let (lexbuf : Lexing.lexbuf) = lexbuf in
      ((let _tok = Obj.magic () in
      {
        _menhir_lexer = lexer;
        _menhir_lexbuf = lexbuf;
        _menhir_token = _tok;
        _menhir_error = false;
      }) : _menhir_env)
    in
    Obj.magic (let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv5) = ((), _menhir_env._menhir_lexbuf.Lexing.lex_curr_p) in
    ((let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | DFUN ->
        _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | EMPTYLIST ->
        _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | EQ ->
        _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | FALSE ->
        _menhir_run41 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | FUN ->
        _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | GT ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | ID _v ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _v
    | IF ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | INTV _v ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _v
    | LET ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv3) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState0 in
        ((let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ID _v ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState176 _v
        | REC ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv1 * _menhir_state) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState176 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | ID _v ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState177 _v
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState177) : 'freshtv2)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState176) : 'freshtv4)
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState0) : 'freshtv6))

# 219 "/Users/trung/.opam/system/lib/menhir/standard.mly"
  


# 6251 "parser.ml"
