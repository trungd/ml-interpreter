
module MenhirBasics = struct
  
  exception Error
  
  type token = 
    | WITH
    | TWOCOLONS
    | TRUE
    | THEN
    | SEP
    | SEMISEMI
    | SEMI
    | RSQBRACKET
    | RPAREN
    | REC
    | RARROW
    | PLUS
    | OR
    | MULT
    | MINUS
    | MATCH
    | LT
    | LSQBRACKET
    | LPAREN
    | LET
    | INTV of (
# 14 "parser.mly"
       (int)
# 31 "parser.ml"
  )
    | IN
    | IF
    | ID of (
# 15 "parser.mly"
       (Syntax.id)
# 38 "parser.ml"
  )
    | GT
    | FUN
    | FALSE
    | EQ
    | EMPTYLIST
    | ELSE
    | DFUN
    | COMMENT
    | ANDKW
    | AND
  
end

include MenhirBasics

let _eRR =
  MenhirBasics.Error

type _menhir_env = {
  _menhir_lexer: Lexing.lexbuf -> token;
  _menhir_lexbuf: Lexing.lexbuf;
  _menhir_token: token;
  mutable _menhir_error: bool
}

and _menhir_state = 
  | MenhirState190
  | MenhirState182
  | MenhirState181
  | MenhirState179
  | MenhirState178
  | MenhirState175
  | MenhirState174
  | MenhirState173
  | MenhirState172
  | MenhirState171
  | MenhirState170
  | MenhirState169
  | MenhirState166
  | MenhirState165
  | MenhirState160
  | MenhirState159
  | MenhirState154
  | MenhirState153
  | MenhirState150
  | MenhirState149
  | MenhirState148
  | MenhirState147
  | MenhirState144
  | MenhirState143
  | MenhirState140
  | MenhirState139
  | MenhirState138
  | MenhirState129
  | MenhirState128
  | MenhirState126
  | MenhirState125
  | MenhirState121
  | MenhirState120
  | MenhirState119
  | MenhirState117
  | MenhirState116
  | MenhirState115
  | MenhirState114
  | MenhirState111
  | MenhirState110
  | MenhirState109
  | MenhirState108
  | MenhirState107
  | MenhirState106
  | MenhirState105
  | MenhirState104
  | MenhirState103
  | MenhirState102
  | MenhirState101
  | MenhirState98
  | MenhirState97
  | MenhirState96
  | MenhirState91
  | MenhirState90
  | MenhirState89
  | MenhirState88
  | MenhirState87
  | MenhirState86
  | MenhirState85
  | MenhirState84
  | MenhirState83
  | MenhirState81
  | MenhirState79
  | MenhirState77
  | MenhirState73
  | MenhirState71
  | MenhirState66
  | MenhirState60
  | MenhirState56
  | MenhirState55
  | MenhirState54
  | MenhirState43
  | MenhirState41
  | MenhirState34
  | MenhirState31
  | MenhirState28
  | MenhirState22
  | MenhirState19
  | MenhirState18
  | MenhirState15
  | MenhirState13
  | MenhirState10
  | MenhirState9
  | MenhirState8
  | MenhirState7
  | MenhirState5
  | MenhirState0

# 1 "parser.mly"
  
open Syntax

# 158 "parser.ml"

let rec _menhir_run101 : _menhir_env -> (('ttv_tail * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | DFUN ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | EMPTYLIST ->
        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | EQ ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | FALSE ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | FUN ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | GT ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | ID _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState101 _v
    | IF ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | INTV _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState101 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState101
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState101

and _menhir_goto_MatchPatternExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_MatchPatternExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv715 * _menhir_state * 'tv_MatchPatternExpr) = Obj.magic _menhir_stack in
    ((assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | RARROW ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv711 * _menhir_state * 'tv_MatchPatternExpr) = Obj.magic _menhir_stack in
        ((let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | AND ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | DFUN ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | EMPTYLIST ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | EQ ->
            _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | FALSE ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | FUN ->
            _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | GT ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | ID _v ->
            _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState138 _v
        | IF ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | INTV _v ->
            _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState138 _v
        | LET ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | LPAREN ->
            _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | LSQBRACKET ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | LT ->
            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | MATCH ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | MULT ->
            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | OR ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | PLUS ->
            _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | TRUE ->
            _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState138) : 'freshtv712)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv713 * _menhir_state * 'tv_MatchPatternExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv714)) : 'freshtv716)

and _menhir_run119 : _menhir_env -> ('ttv_tail * _menhir_state) * _menhir_state * 'tv_LetAndExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | DFUN ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | EMPTYLIST ->
        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | EQ ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | FALSE ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | FUN ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | GT ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | ID _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState119 _v
    | IF ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | INTV _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState119 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState119
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState119

and _menhir_goto_LetRecAndExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_LetRecAndExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState91 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv693 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 329 "parser.ml"
        )) * (
# 15 "parser.mly"
       (Syntax.id)
# 333 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv691 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 339 "parser.ml"
        )) * (
# 15 "parser.mly"
       (Syntax.id)
# 343 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s, (x : (
# 15 "parser.mly"
       (Syntax.id)
# 348 "parser.ml"
        ))), (param : (
# 15 "parser.mly"
       (Syntax.id)
# 352 "parser.ml"
        ))), _, (e : 'tv_Expr)), _), _, (ls : 'tv_LetRecAndExpr)) = _menhir_stack in
        let _5 = () in
        let _3 = () in
        let _v : 'tv_LetRecAndExpr = 
# 29 "parser.mly"
                                                 ( (x, param, e)::ls )
# 359 "parser.ml"
         in
        _menhir_goto_LetRecAndExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv692)) : 'freshtv694)
    | MenhirState98 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv697 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 367 "parser.ml"
        )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 371 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv695 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 377 "parser.ml"
        )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 381 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s, (x : (
# 15 "parser.mly"
       (Syntax.id)
# 386 "parser.ml"
        ))), (param : (
# 15 "parser.mly"
       (Syntax.id)
# 390 "parser.ml"
        ))), _, (e : 'tv_Expr)), _), _, (ls : 'tv_LetRecAndExpr)) = _menhir_stack in
        let _7 = () in
        let _5 = () in
        let _3 = () in
        let _2 = () in
        let _v : 'tv_LetRecAndExpr = 
# 30 "parser.mly"
                                                            ( (x, param, e)::ls )
# 399 "parser.ml"
         in
        _menhir_goto_LetRecAndExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv696)) : 'freshtv698)
    | MenhirState10 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv701 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | IN ->
            _menhir_run101 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv699 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv700)) : 'freshtv702)
    | MenhirState144 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv709 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | IN ->
            _menhir_run101 _menhir_env (Obj.magic _menhir_stack)
        | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv705 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv703 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s), _), _, (ls : 'tv_LetRecAndExpr)) = _menhir_stack in
            let _4 = () in
            let _2 = () in
            let _1 = () in
            let _v : (
# 18 "parser.mly"
      (Syntax.program)
# 437 "parser.ml"
            ) = 
# 48 "parser.mly"
                                    ( RecDecls ls )
# 441 "parser.ml"
             in
            _menhir_goto_toplevel _menhir_env _menhir_stack _menhir_s _v) : 'freshtv704)) : 'freshtv706)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv707 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv708)) : 'freshtv710)
    | _ ->
        _menhir_fail ()

and _menhir_goto_AppExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_AppExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState34 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv685 * _menhir_state * 'tv_MExpr)) * _menhir_state * 'tv_AppExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EMPTYLIST ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState41
        | FALSE ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState41
        | ID _v ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState41 _v
        | INTV _v ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState41 _v
        | LPAREN ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState41
        | LSQBRACKET ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState41
        | TRUE ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState41
        | ANDKW | ELSE | EQ | GT | IN | LET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv683 * _menhir_state * 'tv_MExpr)) * _menhir_state * 'tv_AppExpr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, (l : 'tv_MExpr)), _, (r : 'tv_AppExpr)) = _menhir_stack in
            let _2 = () in
            let _v : 'tv_MExpr = 
# 93 "parser.mly"
                           ( BinOp (Mult, l, r) )
# 486 "parser.ml"
             in
            _menhir_goto_MExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv684)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState41) : 'freshtv686)
    | MenhirState0 | MenhirState181 | MenhirState170 | MenhirState178 | MenhirState174 | MenhirState165 | MenhirState147 | MenhirState159 | MenhirState153 | MenhirState5 | MenhirState138 | MenhirState7 | MenhirState126 | MenhirState8 | MenhirState119 | MenhirState114 | MenhirState116 | MenhirState107 | MenhirState105 | MenhirState101 | MenhirState96 | MenhirState13 | MenhirState15 | MenhirState86 | MenhirState88 | MenhirState22 | MenhirState28 | MenhirState81 | MenhirState79 | MenhirState77 | MenhirState31 | MenhirState43 | MenhirState55 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv689 * _menhir_state * 'tv_AppExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EMPTYLIST ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState60
        | FALSE ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState60
        | ID _v ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState60 _v
        | INTV _v ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState60 _v
        | LPAREN ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState60
        | LSQBRACKET ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState60
        | TRUE ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState60
        | ANDKW | ELSE | EQ | GT | IN | LET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv687 * _menhir_state * 'tv_AppExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, (e : 'tv_AppExpr)) = _menhir_stack in
            let _v : 'tv_MExpr = 
# 95 "parser.mly"
              ( e )
# 520 "parser.ml"
             in
            _menhir_goto_MExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv688)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState60) : 'freshtv690)
    | _ ->
        _menhir_fail ()

and _menhir_reduce22 : _menhir_env -> 'ttv_tail * _menhir_state * 'tv_AExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (_menhir_stack, _menhir_s, (e : 'tv_AExpr)) = _menhir_stack in
    let _v : 'tv_AppExpr = 
# 109 "parser.mly"
            ( e )
# 536 "parser.ml"
     in
    _menhir_goto_AppExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_AppParamListExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_AppParamListExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState41 | MenhirState60 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv677 * _menhir_state * 'tv_AppExpr) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_AppParamListExpr) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv675 * _menhir_state * 'tv_AppExpr) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let ((ls : 'tv_AppParamListExpr) : 'tv_AppParamListExpr) = _v in
        ((let (_menhir_stack, _menhir_s, (e : 'tv_AppExpr)) = _menhir_stack in
        let _v : 'tv_AppExpr = 
# 108 "parser.mly"
                                  ( AppExp(e, ls) )
# 556 "parser.ml"
         in
        _menhir_goto_AppExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv676)) : 'freshtv678)
    | MenhirState66 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv681 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_AppParamListExpr) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv679 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let ((ls : 'tv_AppParamListExpr) : 'tv_AppParamListExpr) = _v in
        ((let (_menhir_stack, _menhir_s, (e : 'tv_AExpr)) = _menhir_stack in
        let _v : 'tv_AppParamListExpr = 
# 117 "parser.mly"
                                 ( e::ls )
# 572 "parser.ml"
         in
        _menhir_goto_AppParamListExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv680)) : 'freshtv682)
    | _ ->
        _menhir_fail ()

and _menhir_run42 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce2 _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run43 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | DFUN ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | EMPTYLIST ->
        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | EQ ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | FALSE ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | FUN ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | GT ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | ID _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState43 _v
    | IF ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | INTV _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState43 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState43

and _menhir_run61 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 14 "parser.mly"
       (int)
# 635 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce1 _menhir_env (Obj.magic _menhir_stack) _menhir_s _v

and _menhir_run62 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 15 "parser.mly"
       (Syntax.id)
# 644 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce4 _menhir_env (Obj.magic _menhir_stack) _menhir_s _v

and _menhir_run63 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce3 _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_goto_toplevel : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 18 "parser.mly"
      (Syntax.program)
# 658 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv673) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : (
# 18 "parser.mly"
      (Syntax.program)
# 667 "parser.ml"
    )) = _v in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv671) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((_1 : (
# 18 "parser.mly"
      (Syntax.program)
# 675 "parser.ml"
    )) : (
# 18 "parser.mly"
      (Syntax.program)
# 679 "parser.ml"
    )) = _v in
    (Obj.magic _1 : 'freshtv672)) : 'freshtv674)

and _menhir_reduce84 : _menhir_env -> (((('ttv_tail * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 686 "parser.ml"
)) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let ((((_menhir_stack, _menhir_s), _, (x : (
# 15 "parser.mly"
       (Syntax.id)
# 692 "parser.ml"
    ))), _, (ls_param : 'tv_FunParamListExpr)), _, (e : 'tv_Expr)) = _menhir_stack in
    let _4 = () in
    let _1 = () in
    let _v : 'tv_TopLetExpr = 
# 37 "parser.mly"
                                               ( [(x, FunExp(ls_param, e))] )
# 699 "parser.ml"
     in
    _menhir_goto_TopLetExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_TopLetExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_TopLetExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState171 | MenhirState175 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv661 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 712 "parser.ml"
        )) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state * 'tv_TopLetExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv659 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 718 "parser.ml"
        )) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state * 'tv_TopLetExpr) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s), _, (x : (
# 15 "parser.mly"
       (Syntax.id)
# 723 "parser.ml"
        ))), _), _, (e : 'tv_Expr)), _, (ls : 'tv_TopLetExpr)) = _menhir_stack in
        let _3 = () in
        let _1 = () in
        let _v : 'tv_TopLetExpr = 
# 35 "parser.mly"
                                   ( (x, e)::ls )
# 730 "parser.ml"
         in
        _menhir_goto_TopLetExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv660)) : 'freshtv662)
    | MenhirState0 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv669 * _menhir_state * 'tv_TopLetExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv665 * _menhir_state * 'tv_TopLetExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv663 * _menhir_state * 'tv_TopLetExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, (ls : 'tv_TopLetExpr)) = _menhir_stack in
            let _2 = () in
            let _v : (
# 18 "parser.mly"
      (Syntax.program)
# 749 "parser.ml"
            ) = 
# 49 "parser.mly"
                         ( Decls ls )
# 753 "parser.ml"
             in
            _menhir_goto_toplevel _menhir_env _menhir_stack _menhir_s _v) : 'freshtv664)) : 'freshtv666)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv667 * _menhir_state * 'tv_TopLetExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv668)) : 'freshtv670)
    | _ ->
        _menhir_fail ()

and _menhir_run172 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv657 * _menhir_state) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState172 in
        let (_v : (
# 15 "parser.mly"
       (Syntax.id)
# 779 "parser.ml"
        )) = _v in
        ((let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv655 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 790 "parser.ml"
            )) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState173 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | DFUN ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | EMPTYLIST ->
                _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | EQ ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | FALSE ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | FUN ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | GT ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | ID _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState174 _v
            | IF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | INTV _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState174 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState174) : 'freshtv656)
        | ID _v ->
            _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState173 _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState173) : 'freshtv658)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState172

and _menhir_goto_TopLetRecExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_TopLetRecExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState148 | MenhirState154 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv641 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 859 "parser.ml"
        )) * (
# 15 "parser.mly"
       (Syntax.id)
# 863 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) * _menhir_state * 'tv_TopLetRecExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv639 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 869 "parser.ml"
        )) * (
# 15 "parser.mly"
       (Syntax.id)
# 873 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) * _menhir_state * 'tv_TopLetRecExpr) = Obj.magic _menhir_stack in
        ((let ((((((_menhir_stack, _menhir_s), _), _, (x : (
# 15 "parser.mly"
       (Syntax.id)
# 878 "parser.ml"
        ))), (param : (
# 15 "parser.mly"
       (Syntax.id)
# 882 "parser.ml"
        ))), _, (e : 'tv_Expr)), _, (ls : 'tv_TopLetRecExpr)) = _menhir_stack in
        let _5 = () in
        let _2 = () in
        let _1 = () in
        let _v : 'tv_TopLetRecExpr = 
# 40 "parser.mly"
                                                   ( (x, param, e)::ls )
# 890 "parser.ml"
         in
        _menhir_goto_TopLetRecExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv640)) : 'freshtv642)
    | MenhirState166 | MenhirState160 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((((('freshtv645 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 898 "parser.ml"
        )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 902 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) * _menhir_state * 'tv_TopLetRecExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((((('freshtv643 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 908 "parser.ml"
        )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 912 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) * _menhir_state * 'tv_TopLetRecExpr) = Obj.magic _menhir_stack in
        ((let ((((((_menhir_stack, _menhir_s), _), _, (x : (
# 15 "parser.mly"
       (Syntax.id)
# 917 "parser.ml"
        ))), (param : (
# 15 "parser.mly"
       (Syntax.id)
# 921 "parser.ml"
        ))), _, (e : 'tv_Expr)), _, (ls : 'tv_TopLetRecExpr)) = _menhir_stack in
        let _7 = () in
        let _5 = () in
        let _4 = () in
        let _2 = () in
        let _1 = () in
        let _v : 'tv_TopLetRecExpr = 
# 41 "parser.mly"
                                                              ( (x, param, e)::ls )
# 931 "parser.ml"
         in
        _menhir_goto_TopLetRecExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv644)) : 'freshtv646)
    | MenhirState0 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv653 * _menhir_state * 'tv_TopLetRecExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv649 * _menhir_state * 'tv_TopLetRecExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv647 * _menhir_state * 'tv_TopLetRecExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, (ls : 'tv_TopLetRecExpr)) = _menhir_stack in
            let _2 = () in
            let _v : (
# 18 "parser.mly"
      (Syntax.program)
# 950 "parser.ml"
            ) = 
# 50 "parser.mly"
                            ( RecDecls ls )
# 954 "parser.ml"
             in
            _menhir_goto_toplevel _menhir_env _menhir_stack _menhir_s _v) : 'freshtv648)) : 'freshtv650)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv651 * _menhir_state * 'tv_TopLetRecExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv652)) : 'freshtv654)
    | _ ->
        _menhir_fail ()

and _menhir_run149 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | REC ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv637 * _menhir_state) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState149 in
        ((let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ID _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv635 * _menhir_state) * _menhir_state) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState150 in
            let (_v : (
# 15 "parser.mly"
       (Syntax.id)
# 988 "parser.ml"
            )) = _v in
            ((let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | EQ ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv625 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 999 "parser.ml"
                )) = Obj.magic _menhir_stack in
                ((let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | FUN ->
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : ((('freshtv621 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1009 "parser.ml"
                    ))) = Obj.magic _menhir_stack in
                    ((let _menhir_env = _menhir_discard _menhir_env in
                    let _tok = _menhir_env._menhir_token in
                    match _tok with
                    | ID _v ->
                        let (_menhir_env : _menhir_env) = _menhir_env in
                        let (_menhir_stack : (((('freshtv617 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1019 "parser.ml"
                        )))) = Obj.magic _menhir_stack in
                        let (_v : (
# 15 "parser.mly"
       (Syntax.id)
# 1024 "parser.ml"
                        )) = _v in
                        ((let _menhir_stack = (_menhir_stack, _v) in
                        let _menhir_env = _menhir_discard _menhir_env in
                        let _tok = _menhir_env._menhir_token in
                        match _tok with
                        | RARROW ->
                            let (_menhir_env : _menhir_env) = _menhir_env in
                            let (_menhir_stack : ((((('freshtv613 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1035 "parser.ml"
                            )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 1039 "parser.ml"
                            )) = Obj.magic _menhir_stack in
                            ((let _menhir_env = _menhir_discard _menhir_env in
                            let _tok = _menhir_env._menhir_token in
                            match _tok with
                            | AND ->
                                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | DFUN ->
                                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | EMPTYLIST ->
                                _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | EQ ->
                                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | FALSE ->
                                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | FUN ->
                                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | GT ->
                                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | ID _v ->
                                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState159 _v
                            | IF ->
                                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | INTV _v ->
                                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState159 _v
                            | LET ->
                                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | LPAREN ->
                                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | LSQBRACKET ->
                                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | LT ->
                                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | MATCH ->
                                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | MULT ->
                                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | OR ->
                                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | PLUS ->
                                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | TRUE ->
                                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState159
                            | _ ->
                                assert (not _menhir_env._menhir_error);
                                _menhir_env._menhir_error <- true;
                                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState159) : 'freshtv614)
                        | _ ->
                            assert (not _menhir_env._menhir_error);
                            _menhir_env._menhir_error <- true;
                            let (_menhir_env : _menhir_env) = _menhir_env in
                            let (_menhir_stack : ((((('freshtv615 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1093 "parser.ml"
                            )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 1097 "parser.ml"
                            )) = Obj.magic _menhir_stack in
                            ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
                            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv616)) : 'freshtv618)
                    | _ ->
                        assert (not _menhir_env._menhir_error);
                        _menhir_env._menhir_error <- true;
                        let (_menhir_env : _menhir_env) = _menhir_env in
                        let (_menhir_stack : (((('freshtv619 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1108 "parser.ml"
                        )))) = Obj.magic _menhir_stack in
                        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv620)) : 'freshtv622)
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : ((('freshtv623 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1119 "parser.ml"
                    ))) = Obj.magic _menhir_stack in
                    ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv624)) : 'freshtv626)
            | ID _v ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv631 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1128 "parser.ml"
                )) = Obj.magic _menhir_stack in
                let (_v : (
# 15 "parser.mly"
       (Syntax.id)
# 1133 "parser.ml"
                )) = _v in
                ((let _menhir_stack = (_menhir_stack, _v) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | EQ ->
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : ((('freshtv627 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1144 "parser.ml"
                    )) * (
# 15 "parser.mly"
       (Syntax.id)
# 1148 "parser.ml"
                    )) = Obj.magic _menhir_stack in
                    ((let _menhir_env = _menhir_discard _menhir_env in
                    let _tok = _menhir_env._menhir_token in
                    match _tok with
                    | AND ->
                        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | DFUN ->
                        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | EMPTYLIST ->
                        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | EQ ->
                        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | FALSE ->
                        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | FUN ->
                        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | GT ->
                        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | ID _v ->
                        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState153 _v
                    | IF ->
                        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | INTV _v ->
                        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState153 _v
                    | LET ->
                        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | LPAREN ->
                        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | LSQBRACKET ->
                        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | LT ->
                        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | MATCH ->
                        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | MULT ->
                        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | OR ->
                        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | PLUS ->
                        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | TRUE ->
                        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState153
                    | _ ->
                        assert (not _menhir_env._menhir_error);
                        _menhir_env._menhir_error <- true;
                        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState153) : 'freshtv628)
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : ((('freshtv629 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1202 "parser.ml"
                    )) * (
# 15 "parser.mly"
       (Syntax.id)
# 1206 "parser.ml"
                    )) = Obj.magic _menhir_stack in
                    ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv630)) : 'freshtv632)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv633 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1217 "parser.ml"
                )) = Obj.magic _menhir_stack in
                ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv634)) : 'freshtv636)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState150) : 'freshtv638)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState149

and _menhir_goto_MatchListExprs : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_MatchListExprs -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState140 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv597 * _menhir_state * 'tv_MatchPatternExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_MatchListExprs) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv595 * _menhir_state * 'tv_MatchPatternExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let ((match_list : 'tv_MatchListExprs) : 'tv_MatchListExprs) = _v in
        ((let (((_menhir_stack, _menhir_s, (match_pattern : 'tv_MatchPatternExpr)), _, (exp : 'tv_Expr)), _) = _menhir_stack in
        let _4 = () in
        let _2 = () in
        let _v : 'tv_MatchListExprs = 
# 176 "parser.mly"
                                                                                 ( (match_pattern, exp) :: match_list )
# 1248 "parser.ml"
         in
        _menhir_goto_MatchListExprs _menhir_env _menhir_stack _menhir_s _v) : 'freshtv596)) : 'freshtv598)
    | MenhirState129 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv611 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_MatchListExprs) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv609 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let ((match_list : 'tv_MatchListExprs) : 'tv_MatchListExprs) = _v in
        ((let (((_menhir_stack, _menhir_s), _, (exp : 'tv_Expr)), _) = _menhir_stack in
        let _3 = () in
        let _1 = () in
        let _v : 'tv_MatchExpr = 
# 180 "parser.mly"
                                                  ( MatchExp(exp, match_list) )
# 1266 "parser.ml"
         in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv607) = _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_MatchExpr) = _v in
        ((match _menhir_s with
        | MenhirState81 | MenhirState79 | MenhirState77 | MenhirState34 | MenhirState31 ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv601) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_MatchExpr) = _v in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv599) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let ((e : 'tv_MatchExpr) : 'tv_MatchExpr) = _v in
            ((let _v : 'tv_AExprEx = 
# 140 "parser.mly"
              ( e )
# 1285 "parser.ml"
             in
            _menhir_goto_AExprEx _menhir_env _menhir_stack _menhir_s _v) : 'freshtv600)) : 'freshtv602)
        | MenhirState0 | MenhirState181 | MenhirState178 | MenhirState174 | MenhirState170 | MenhirState165 | MenhirState159 | MenhirState153 | MenhirState147 | MenhirState138 | MenhirState5 | MenhirState126 | MenhirState7 | MenhirState8 | MenhirState119 | MenhirState116 | MenhirState114 | MenhirState107 | MenhirState105 | MenhirState101 | MenhirState96 | MenhirState13 | MenhirState88 | MenhirState86 | MenhirState15 | MenhirState22 | MenhirState28 | MenhirState55 | MenhirState43 ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv605) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_MatchExpr) = _v in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv603) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let ((e : 'tv_MatchExpr) : 'tv_MatchExpr) = _v in
            ((let _v : 'tv_Expr = 
# 65 "parser.mly"
              ( e )
# 1300 "parser.ml"
             in
            _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv604)) : 'freshtv606)
        | _ ->
            _menhir_fail ()) : 'freshtv608)) : 'freshtv610)) : 'freshtv612)
    | _ ->
        _menhir_fail ()

and _menhir_run130 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv591 * _menhir_state) = Obj.magic _menhir_stack in
        let (_v : (
# 15 "parser.mly"
       (Syntax.id)
# 1320 "parser.ml"
        )) = _v in
        ((let _menhir_stack = (_menhir_stack, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RSQBRACKET ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv587 * _menhir_state) * (
# 15 "parser.mly"
       (Syntax.id)
# 1331 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv585 * _menhir_state) * (
# 15 "parser.mly"
       (Syntax.id)
# 1338 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s), (id : (
# 15 "parser.mly"
       (Syntax.id)
# 1343 "parser.ml"
            ))) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_MatchPatternExpr = 
# 172 "parser.mly"
                                ( SingleElementList(id) )
# 1350 "parser.ml"
             in
            _menhir_goto_MatchPatternExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv586)) : 'freshtv588)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv589 * _menhir_state) * (
# 15 "parser.mly"
       (Syntax.id)
# 1360 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv590)) : 'freshtv592)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv593 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv594)

and _menhir_run133 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 15 "parser.mly"
       (Syntax.id)
# 1375 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | TWOCOLONS ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv581 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1387 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ID _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv577 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1397 "parser.ml"
            ))) = Obj.magic _menhir_stack in
            let (_v : (
# 15 "parser.mly"
       (Syntax.id)
# 1402 "parser.ml"
            )) = _v in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv575 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1409 "parser.ml"
            ))) = Obj.magic _menhir_stack in
            let ((id2 : (
# 15 "parser.mly"
       (Syntax.id)
# 1414 "parser.ml"
            )) : (
# 15 "parser.mly"
       (Syntax.id)
# 1418 "parser.ml"
            )) = _v in
            ((let (_menhir_stack, _menhir_s, (id1 : (
# 15 "parser.mly"
       (Syntax.id)
# 1423 "parser.ml"
            ))) = _menhir_stack in
            let _2 = () in
            let _v : 'tv_MatchPatternExpr = 
# 173 "parser.mly"
                            ( ListHeadTail(id1, id2) )
# 1429 "parser.ml"
             in
            _menhir_goto_MatchPatternExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv576)) : 'freshtv578)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv579 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1439 "parser.ml"
            ))) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv580)) : 'freshtv582)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv583 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1450 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv584)

and _menhir_run136 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv573) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_MatchPatternExpr = 
# 171 "parser.mly"
              ( EmptyList )
# 1465 "parser.ml"
     in
    _menhir_goto_MatchPatternExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv574)

and _menhir_goto_ListItemExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_ListItemExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState7 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv567 * _menhir_state) * _menhir_state * 'tv_ListItemExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RSQBRACKET ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv563 * _menhir_state) * _menhir_state * 'tv_ListItemExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv561 * _menhir_state) * _menhir_state * 'tv_ListItemExpr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s), _, (ls : 'tv_ListItemExpr)) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_ListExpr = 
# 167 "parser.mly"
                                          ( ListExp(ls) )
# 1491 "parser.ml"
             in
            _menhir_goto_ListExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv562)) : 'freshtv564)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv565 * _menhir_state) * _menhir_state * 'tv_ListItemExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv566)) : 'freshtv568)
    | MenhirState126 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv571 * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_ListItemExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv569 * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_ListItemExpr) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, (exp : 'tv_Expr)), _), _, (ls : 'tv_ListItemExpr)) = _menhir_stack in
        let _2 = () in
        let _v : 'tv_ListItemExpr = 
# 163 "parser.mly"
                                  ( exp::ls )
# 1511 "parser.ml"
         in
        _menhir_goto_ListItemExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv570)) : 'freshtv572)
    | _ ->
        _menhir_fail ()

and _menhir_goto_LetExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_LetExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState81 | MenhirState79 | MenhirState77 | MenhirState31 | MenhirState34 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv555) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_LetExpr) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv553) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let ((e : 'tv_LetExpr) : 'tv_LetExpr) = _v in
        ((let _v : 'tv_AExprEx = 
# 135 "parser.mly"
           ( e )
# 1532 "parser.ml"
         in
        _menhir_goto_AExprEx _menhir_env _menhir_stack _menhir_s _v) : 'freshtv554)) : 'freshtv556)
    | MenhirState0 | MenhirState181 | MenhirState178 | MenhirState174 | MenhirState170 | MenhirState165 | MenhirState159 | MenhirState153 | MenhirState147 | MenhirState138 | MenhirState5 | MenhirState126 | MenhirState7 | MenhirState8 | MenhirState119 | MenhirState116 | MenhirState114 | MenhirState107 | MenhirState105 | MenhirState101 | MenhirState96 | MenhirState13 | MenhirState88 | MenhirState86 | MenhirState15 | MenhirState22 | MenhirState28 | MenhirState55 | MenhirState43 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv559) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_LetExpr) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv557) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let ((e : 'tv_LetExpr) : 'tv_LetExpr) = _v in
        ((let _v : 'tv_Expr = 
# 54 "parser.mly"
           ( e )
# 1547 "parser.ml"
         in
        _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv558)) : 'freshtv560)
    | _ ->
        _menhir_fail ()

and _menhir_run116 : _menhir_env -> (((('ttv_tail * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1556 "parser.ml"
)) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | DFUN ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | EMPTYLIST ->
        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | EQ ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | FALSE ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | FUN ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | GT ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | ID _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState116 _v
    | IF ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | INTV _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState116 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState116
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState116

and _menhir_reduce55 : _menhir_env -> (('ttv_tail * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1609 "parser.ml"
)) * _menhir_state) * _menhir_state * 'tv_Expr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (((_menhir_stack, _menhir_s, (x : (
# 15 "parser.mly"
       (Syntax.id)
# 1615 "parser.ml"
    ))), _), _, (e : 'tv_Expr)) = _menhir_stack in
    let _2 = () in
    let _v : 'tv_LetAndExpr = 
# 24 "parser.mly"
                 ( [(x ,e)] )
# 1621 "parser.ml"
     in
    _menhir_goto_LetAndExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_run109 : _menhir_env -> (('ttv_tail * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1628 "parser.ml"
)) * _menhir_state) * _menhir_state * 'tv_Expr -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv551) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState109 in
        let (_v : (
# 15 "parser.mly"
       (Syntax.id)
# 1642 "parser.ml"
        )) = _v in
        ((let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            _menhir_run107 _menhir_env (Obj.magic _menhir_stack) MenhirState110
        | ID _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv549 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1655 "parser.ml"
            )) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState110 in
            let (_v : (
# 15 "parser.mly"
       (Syntax.id)
# 1661 "parser.ml"
            )) = _v in
            ((let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | EQ ->
                _menhir_run105 _menhir_env (Obj.magic _menhir_stack) MenhirState111
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState111) : 'freshtv550)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState110) : 'freshtv552)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState109

and _menhir_goto_LetAndExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_LetAndExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState109 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv535 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1691 "parser.ml"
        )) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_LetAndExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv533 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1697 "parser.ml"
        )) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_LetAndExpr) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s, (x : (
# 15 "parser.mly"
       (Syntax.id)
# 1702 "parser.ml"
        ))), _), _, (e : 'tv_Expr)), _), _, (ls : 'tv_LetAndExpr)) = _menhir_stack in
        let _4 = () in
        let _2 = () in
        let _v : 'tv_LetAndExpr = 
# 23 "parser.mly"
                                     ( (x,e)::ls )
# 1709 "parser.ml"
         in
        _menhir_goto_LetAndExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv534)) : 'freshtv536)
    | MenhirState9 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv539 * _menhir_state) * _menhir_state * 'tv_LetAndExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | IN ->
            _menhir_run119 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv537 * _menhir_state) * _menhir_state * 'tv_LetAndExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv538)) : 'freshtv540)
    | MenhirState143 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv547 * _menhir_state) * _menhir_state * 'tv_LetAndExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | IN ->
            _menhir_run119 _menhir_env (Obj.magic _menhir_stack)
        | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv543 * _menhir_state) * _menhir_state * 'tv_LetAndExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv541 * _menhir_state) * _menhir_state * 'tv_LetAndExpr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s), _, (ls : 'tv_LetAndExpr)) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : (
# 18 "parser.mly"
      (Syntax.program)
# 1746 "parser.ml"
            ) = 
# 47 "parser.mly"
                             ( AndDecls ls )
# 1750 "parser.ml"
             in
            _menhir_goto_toplevel _menhir_env _menhir_stack _menhir_s _v) : 'freshtv542)) : 'freshtv544)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv545 * _menhir_state) * _menhir_state * 'tv_LetAndExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv546)) : 'freshtv548)
    | _ ->
        _menhir_fail ()

and _menhir_reduce62 : _menhir_env -> ((((('ttv_tail * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1766 "parser.ml"
)))) * (
# 15 "parser.mly"
       (Syntax.id)
# 1770 "parser.ml"
))) * _menhir_state * 'tv_Expr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (((_menhir_stack, _menhir_s, (x : (
# 15 "parser.mly"
       (Syntax.id)
# 1776 "parser.ml"
    ))), (param : (
# 15 "parser.mly"
       (Syntax.id)
# 1780 "parser.ml"
    ))), _, (e : 'tv_Expr)) = _menhir_stack in
    let _5 = () in
    let _3 = () in
    let _2 = () in
    let _v : 'tv_LetRecAndExpr = 
# 32 "parser.mly"
                                     ( [(x, param, e)] )
# 1788 "parser.ml"
     in
    _menhir_goto_LetRecAndExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_run98 : _menhir_env -> ((((('ttv_tail * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1795 "parser.ml"
)))) * (
# 15 "parser.mly"
       (Syntax.id)
# 1799 "parser.ml"
))) * _menhir_state * 'tv_Expr -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState98 _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState98

and _menhir_reduce61 : _menhir_env -> ((('ttv_tail * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1816 "parser.ml"
)) * (
# 15 "parser.mly"
       (Syntax.id)
# 1820 "parser.ml"
))) * _menhir_state * 'tv_Expr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (((_menhir_stack, _menhir_s, (x : (
# 15 "parser.mly"
       (Syntax.id)
# 1826 "parser.ml"
    ))), (param : (
# 15 "parser.mly"
       (Syntax.id)
# 1830 "parser.ml"
    ))), _, (e : 'tv_Expr)) = _menhir_stack in
    let _3 = () in
    let _v : 'tv_LetRecAndExpr = 
# 31 "parser.mly"
                          ( [(x, param, e)] )
# 1836 "parser.ml"
     in
    _menhir_goto_LetRecAndExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_run91 : _menhir_env -> ((('ttv_tail * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 1843 "parser.ml"
)) * (
# 15 "parser.mly"
       (Syntax.id)
# 1847 "parser.ml"
))) * _menhir_state * 'tv_Expr -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState91 _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState91

and _menhir_goto_AExprEx : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_AExprEx -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv531) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : 'tv_AExprEx) = _v in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv529) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((e : 'tv_AExprEx) : 'tv_AExprEx) = _v in
    ((let _v : 'tv_AppExpr = 
# 110 "parser.mly"
              ( e )
# 1874 "parser.ml"
     in
    _menhir_goto_AppExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv530)) : 'freshtv532)

and _menhir_run55 : _menhir_env -> 'ttv_tail * _menhir_state * 'tv_Expr -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | DFUN ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | EMPTYLIST ->
        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | EQ ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | FALSE ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | FUN ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | GT ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | ID _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState55 _v
    | IF ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | INTV _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState55 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState55
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState55

and _menhir_reduce5 : _menhir_env -> ('ttv_tail * _menhir_state) * _menhir_state * 'tv_Expr -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _ ->
    let ((_menhir_stack, _menhir_s), _, (e : 'tv_Expr)) = _menhir_stack in
    let _3 = () in
    let _1 = () in
    let _v : 'tv_AExpr = 
# 125 "parser.mly"
                       ( e )
# 1935 "parser.ml"
     in
    _menhir_goto_AExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_run31 : _menhir_env -> 'ttv_tail * _menhir_state * 'tv_PExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DFUN ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | EMPTYLIST ->
        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | FALSE ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | FUN ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | ID _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState31 _v
    | IF ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | INTV _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState31 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState31

and _menhir_run34 : _menhir_env -> 'ttv_tail * _menhir_state * 'tv_MExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DFUN ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | EMPTYLIST ->
        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | FALSE ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | FUN ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | ID _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState34 _v
    | IF ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | INTV _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState34 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState34

and _menhir_goto_FunParamListExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_FunParamListExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState104 | MenhirState19 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv503 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2018 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv501 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2024 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, (id : (
# 15 "parser.mly"
       (Syntax.id)
# 2029 "parser.ml"
        ))), _, (ls_param : 'tv_FunParamListExpr)) = _menhir_stack in
        let _v : 'tv_FunParamListExpr = 
# 159 "parser.mly"
                                  ( id :: ls_param )
# 2034 "parser.ml"
         in
        _menhir_goto_FunParamListExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv502)) : 'freshtv504)
    | MenhirState18 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv509 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RARROW ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv505 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | DFUN ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | EMPTYLIST ->
                _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | EQ ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | FALSE ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | FUN ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | GT ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | ID _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState22 _v
            | IF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | INTV _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState22 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState22
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState22) : 'freshtv506)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv507 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv508)) : 'freshtv510)
    | MenhirState103 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv515 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2103 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv511 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2113 "parser.ml"
            )) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | DFUN ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | EMPTYLIST ->
                _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | EQ ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | FALSE ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | FUN ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | GT ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | ID _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState114 _v
            | IF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | INTV _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState114 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState114
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState114) : 'freshtv512)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv513 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2167 "parser.ml"
            )) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv514)) : 'freshtv516)
    | MenhirState173 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv521 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2176 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv517 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2186 "parser.ml"
            )) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | DFUN ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | EMPTYLIST ->
                _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | EQ ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | FALSE ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | FUN ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | GT ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | ID _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState178 _v
            | IF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | INTV _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState178 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState178
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState178) : 'freshtv518)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv519 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2240 "parser.ml"
            )) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv520)) : 'freshtv522)
    | MenhirState169 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv527 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2249 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv523 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2259 "parser.ml"
            )) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | DFUN ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | EMPTYLIST ->
                _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | EQ ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | FALSE ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | FUN ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | GT ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | ID _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState181 _v
            | IF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | INTV _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState181 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState181) : 'freshtv524)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv525 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2313 "parser.ml"
            )) * _menhir_state * 'tv_FunParamListExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv526)) : 'freshtv528)
    | _ ->
        _menhir_fail ()

and _menhir_goto_AExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_AExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState41 | MenhirState66 | MenhirState60 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv481 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EMPTYLIST ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | FALSE ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | ID _v ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState66 _v
        | INTV _v ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState66 _v
        | LPAREN ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | LSQBRACKET ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | TRUE ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | ANDKW | ELSE | EQ | GT | IN | LET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv479 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, (e : 'tv_AExpr)) = _menhir_stack in
            let _v : 'tv_AppParamListExpr = 
# 118 "parser.mly"
            ( [e] )
# 2351 "parser.ml"
             in
            _menhir_goto_AppParamListExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv480)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState66) : 'freshtv482)
    | MenhirState0 | MenhirState181 | MenhirState170 | MenhirState178 | MenhirState174 | MenhirState165 | MenhirState147 | MenhirState159 | MenhirState153 | MenhirState5 | MenhirState138 | MenhirState7 | MenhirState126 | MenhirState8 | MenhirState119 | MenhirState114 | MenhirState116 | MenhirState107 | MenhirState105 | MenhirState101 | MenhirState96 | MenhirState13 | MenhirState15 | MenhirState86 | MenhirState88 | MenhirState22 | MenhirState28 | MenhirState43 | MenhirState55 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv489 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | AND ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv483 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | EMPTYLIST ->
                _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState73
            | FALSE ->
                _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState73
            | ID _v ->
                _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState73 _v
            | INTV _v ->
                _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState73 _v
            | LPAREN ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState73
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState73
            | TRUE ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState73
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState73) : 'freshtv484)
        | OR ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv485 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | EMPTYLIST ->
                _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState71
            | FALSE ->
                _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState71
            | ID _v ->
                _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState71 _v
            | INTV _v ->
                _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState71 _v
            | LPAREN ->
                _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState71
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState71
            | TRUE ->
                _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState71
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState71) : 'freshtv486)
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | TWOCOLONS | WITH ->
            _menhir_reduce22 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv487 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv488)) : 'freshtv490)
    | MenhirState71 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv493 * _menhir_state * 'tv_AExpr)) * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv491 * _menhir_state * 'tv_AExpr)) * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, (l : 'tv_AExpr)), _, (r : 'tv_AExpr)) = _menhir_stack in
        let _2 = () in
        let _v : 'tv_OrExpr = 
# 103 "parser.mly"
                       ( BinOp(Or, l, r) )
# 2431 "parser.ml"
         in
        _menhir_goto_OrExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv492)) : 'freshtv494)
    | MenhirState73 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv497 * _menhir_state * 'tv_AExpr)) * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv495 * _menhir_state * 'tv_AExpr)) * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, (l : 'tv_AExpr)), _, (r : 'tv_AExpr)) = _menhir_stack in
        let _2 = () in
        let _v : 'tv_AndExpr = 
# 99 "parser.mly"
                        ( BinOp(And, l, r) )
# 2444 "parser.ml"
         in
        _menhir_goto_AndExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv496)) : 'freshtv498)
    | MenhirState81 | MenhirState79 | MenhirState77 | MenhirState31 | MenhirState34 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv499 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        (_menhir_reduce22 _menhir_env (Obj.magic _menhir_stack) : 'freshtv500)
    | _ ->
        _menhir_fail ()

and _menhir_fail : unit -> 'a =
  fun () ->
    Printf.fprintf Pervasives.stderr "Internal failure -- please contact the parser generator's developers.\n%!";
    assert false

and _menhir_reduce6 : _menhir_env -> 'ttv_tail * _menhir_state * 'tv_ListExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (_menhir_stack, _menhir_s, (e : 'tv_ListExpr)) = _menhir_stack in
    let _v : 'tv_AExpr = 
# 126 "parser.mly"
             ( e )
# 2465 "parser.ml"
     in
    _menhir_goto_AExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_Expr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_Expr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState43 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv335 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv333 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState54 in
            ((let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce5 _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv334)
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState54
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState54) : 'freshtv336)
    | MenhirState55 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv345 * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState56
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv343 * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s, (e1 : 'tv_Expr)), _), _, (e2 : 'tv_Expr)) = _menhir_stack in
            let _2 = () in
            let _v : 'tv_AppendExpr = 
# 114 "parser.mly"
                              ( AppendExp(e1, e2) )
# 2507 "parser.ml"
             in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv341) = _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_AppendExpr) = _v in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv339) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_AppendExpr) = _v in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv337) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let ((e : 'tv_AppendExpr) : 'tv_AppendExpr) = _v in
            ((let _v : 'tv_Expr = 
# 63 "parser.mly"
               ( e )
# 2524 "parser.ml"
             in
            _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv338)) : 'freshtv340)) : 'freshtv342)) : 'freshtv344)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState56) : 'freshtv346)
    | MenhirState28 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv359 * _menhir_state) * (
# 15 "parser.mly"
       (Syntax.id)
# 2536 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState83
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv357 * _menhir_state) * (
# 15 "parser.mly"
       (Syntax.id)
# 2548 "parser.ml"
            ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s), (x : (
# 15 "parser.mly"
       (Syntax.id)
# 2553 "parser.ml"
            ))), _, (e : 'tv_Expr)) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_DFunExpr = 
# 156 "parser.mly"
                          ( DFunExp(x, e) )
# 2560 "parser.ml"
             in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv355) = _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_DFunExpr) = _v in
            ((match _menhir_s with
            | MenhirState81 | MenhirState79 | MenhirState77 | MenhirState31 | MenhirState34 ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv349) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let (_v : 'tv_DFunExpr) = _v in
                ((let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv347) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let ((e : 'tv_DFunExpr) : 'tv_DFunExpr) = _v in
                ((let _v : 'tv_AExprEx = 
# 138 "parser.mly"
             ( e )
# 2579 "parser.ml"
                 in
                _menhir_goto_AExprEx _menhir_env _menhir_stack _menhir_s _v) : 'freshtv348)) : 'freshtv350)
            | MenhirState0 | MenhirState181 | MenhirState170 | MenhirState178 | MenhirState174 | MenhirState165 | MenhirState147 | MenhirState159 | MenhirState153 | MenhirState5 | MenhirState138 | MenhirState7 | MenhirState126 | MenhirState8 | MenhirState119 | MenhirState114 | MenhirState116 | MenhirState107 | MenhirState105 | MenhirState101 | MenhirState96 | MenhirState13 | MenhirState15 | MenhirState86 | MenhirState88 | MenhirState22 | MenhirState28 | MenhirState43 | MenhirState55 ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv353) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let (_v : 'tv_DFunExpr) = _v in
                ((let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv351) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let ((e : 'tv_DFunExpr) : 'tv_DFunExpr) = _v in
                ((let _v : 'tv_Expr = 
# 62 "parser.mly"
             ( e )
# 2594 "parser.ml"
                 in
                _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv352)) : 'freshtv354)
            | _ ->
                _menhir_fail ()) : 'freshtv356)) : 'freshtv358)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState83) : 'freshtv360)
    | MenhirState22 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv373 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv371 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s), _, (ls_param : 'tv_FunParamListExpr)), _, (e : 'tv_Expr)) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_FunExpr = 
# 153 "parser.mly"
                                              ( FunExp(ls_param, e) )
# 2620 "parser.ml"
             in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv369) = _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_FunExpr) = _v in
            ((match _menhir_s with
            | MenhirState81 | MenhirState79 | MenhirState77 | MenhirState31 | MenhirState34 ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv363) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let (_v : 'tv_FunExpr) = _v in
                ((let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv361) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let ((e : 'tv_FunExpr) : 'tv_FunExpr) = _v in
                ((let _v : 'tv_AExprEx = 
# 137 "parser.mly"
            ( e )
# 2639 "parser.ml"
                 in
                _menhir_goto_AExprEx _menhir_env _menhir_stack _menhir_s _v) : 'freshtv362)) : 'freshtv364)
            | MenhirState0 | MenhirState181 | MenhirState178 | MenhirState174 | MenhirState170 | MenhirState165 | MenhirState159 | MenhirState153 | MenhirState147 | MenhirState138 | MenhirState5 | MenhirState126 | MenhirState7 | MenhirState8 | MenhirState119 | MenhirState116 | MenhirState114 | MenhirState107 | MenhirState105 | MenhirState101 | MenhirState96 | MenhirState13 | MenhirState88 | MenhirState86 | MenhirState15 | MenhirState22 | MenhirState28 | MenhirState55 | MenhirState43 ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv367) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let (_v : 'tv_FunExpr) = _v in
                ((let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv365) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let ((e : 'tv_FunExpr) : 'tv_FunExpr) = _v in
                ((let _v : 'tv_Expr = 
# 61 "parser.mly"
            ( e )
# 2654 "parser.ml"
                 in
                _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv366)) : 'freshtv368)
            | _ ->
                _menhir_fail ()) : 'freshtv370)) : 'freshtv372)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState84) : 'freshtv374)
    | MenhirState15 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv377 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | THEN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv375 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState85 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | DFUN ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | EMPTYLIST ->
                _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | EQ ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | FALSE ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | FUN ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | GT ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | ID _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState86 _v
            | IF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | INTV _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState86 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState86
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState86) : 'freshtv376)
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState85
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState85) : 'freshtv378)
    | MenhirState86 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv381 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ELSE ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv379 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState87 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | DFUN ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | EMPTYLIST ->
                _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | EQ ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | FALSE ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | FUN ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | GT ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | ID _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState88 _v
            | IF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | INTV _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState88 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState88
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState88) : 'freshtv380)
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState87
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState87) : 'freshtv382)
    | MenhirState88 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv395 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState89
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv393 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let ((((((_menhir_stack, _menhir_s), _, (c : 'tv_Expr)), _), _, (t : 'tv_Expr)), _), _, (e : 'tv_Expr)) = _menhir_stack in
            let _5 = () in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_IfExpr = 
# 143 "parser.mly"
                                      ( IfExp (c, t, e) )
# 2805 "parser.ml"
             in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv391) = _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_IfExpr) = _v in
            ((match _menhir_s with
            | MenhirState81 | MenhirState79 | MenhirState77 | MenhirState31 | MenhirState34 ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv385) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let (_v : 'tv_IfExpr) = _v in
                ((let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv383) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let ((e : 'tv_IfExpr) : 'tv_IfExpr) = _v in
                ((let _v : 'tv_AExprEx = 
# 134 "parser.mly"
           ( e )
# 2824 "parser.ml"
                 in
                _menhir_goto_AExprEx _menhir_env _menhir_stack _menhir_s _v) : 'freshtv384)) : 'freshtv386)
            | MenhirState0 | MenhirState181 | MenhirState178 | MenhirState174 | MenhirState170 | MenhirState165 | MenhirState159 | MenhirState153 | MenhirState147 | MenhirState138 | MenhirState5 | MenhirState126 | MenhirState7 | MenhirState8 | MenhirState119 | MenhirState116 | MenhirState114 | MenhirState107 | MenhirState105 | MenhirState101 | MenhirState96 | MenhirState13 | MenhirState88 | MenhirState86 | MenhirState15 | MenhirState22 | MenhirState28 | MenhirState55 | MenhirState43 ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv389) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let (_v : 'tv_IfExpr) = _v in
                ((let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv387) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let ((e : 'tv_IfExpr) : 'tv_IfExpr) = _v in
                ((let _v : 'tv_Expr = 
# 53 "parser.mly"
           ( e )
# 2839 "parser.ml"
                 in
                _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv388)) : 'freshtv390)
            | _ ->
                _menhir_fail ()) : 'freshtv392)) : 'freshtv394)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState89) : 'freshtv396)
    | MenhirState13 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv397 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2853 "parser.ml"
        )) * (
# 15 "parser.mly"
       (Syntax.id)
# 2857 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ANDKW ->
            _menhir_run91 _menhir_env (Obj.magic _menhir_stack) MenhirState90
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState90
        | IN | SEMISEMI ->
            _menhir_reduce61 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState90) : 'freshtv398)
    | MenhirState96 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv399 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2877 "parser.ml"
        )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 2881 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ANDKW ->
            _menhir_run98 _menhir_env (Obj.magic _menhir_stack) MenhirState97
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState97
        | IN | SEMISEMI ->
            _menhir_reduce62 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState97) : 'freshtv400)
    | MenhirState101 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv413 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState102
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((('freshtv411 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let ((((_menhir_stack, _menhir_s), _), _, (ls : 'tv_LetRecAndExpr)), _, (e : 'tv_Expr)) = _menhir_stack in
            let _4 = () in
            let _2 = () in
            let _1 = () in
            let _v : 'tv_LetRecExpr = 
# 150 "parser.mly"
                                     ( LetRecExp(ls, e) )
# 2914 "parser.ml"
             in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv409) = _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_LetRecExpr) = _v in
            ((match _menhir_s with
            | MenhirState81 | MenhirState79 | MenhirState77 | MenhirState31 | MenhirState34 ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv403) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let (_v : 'tv_LetRecExpr) = _v in
                ((let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv401) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let ((e : 'tv_LetRecExpr) : 'tv_LetRecExpr) = _v in
                ((let _v : 'tv_AExprEx = 
# 136 "parser.mly"
               ( e )
# 2933 "parser.ml"
                 in
                _menhir_goto_AExprEx _menhir_env _menhir_stack _menhir_s _v) : 'freshtv402)) : 'freshtv404)
            | MenhirState0 | MenhirState181 | MenhirState178 | MenhirState174 | MenhirState170 | MenhirState165 | MenhirState159 | MenhirState153 | MenhirState147 | MenhirState138 | MenhirState5 | MenhirState126 | MenhirState7 | MenhirState8 | MenhirState119 | MenhirState116 | MenhirState114 | MenhirState107 | MenhirState105 | MenhirState101 | MenhirState96 | MenhirState13 | MenhirState88 | MenhirState86 | MenhirState15 | MenhirState22 | MenhirState28 | MenhirState55 | MenhirState43 ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv407) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let (_v : 'tv_LetRecExpr) = _v in
                ((let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv405) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let ((e : 'tv_LetRecExpr) : 'tv_LetRecExpr) = _v in
                ((let _v : 'tv_Expr = 
# 55 "parser.mly"
               ( e )
# 2948 "parser.ml"
                 in
                _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv406)) : 'freshtv408)
            | _ ->
                _menhir_fail ()) : 'freshtv410)) : 'freshtv412)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState102) : 'freshtv414)
    | MenhirState105 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv417 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2962 "parser.ml"
        )) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2966 "parser.ml"
        )) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState106
        | IN | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv415 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2978 "parser.ml"
            )) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 2982 "parser.ml"
            )) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let ((((_menhir_stack, _menhir_s, (x : (
# 15 "parser.mly"
       (Syntax.id)
# 2987 "parser.ml"
            ))), _, (param : (
# 15 "parser.mly"
       (Syntax.id)
# 2991 "parser.ml"
            ))), _), _, (e : 'tv_Expr)) = _menhir_stack in
            let _3 = () in
            let _v : 'tv_LetAndExpr = 
# 25 "parser.mly"
                          ( [(x, FunExp([param], e))] )
# 2997 "parser.ml"
             in
            _menhir_goto_LetAndExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv416)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState106) : 'freshtv418)
    | MenhirState107 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv419 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3009 "parser.ml"
        )) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ANDKW ->
            _menhir_run109 _menhir_env (Obj.magic _menhir_stack) MenhirState108
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState108
        | IN | SEMISEMI ->
            _menhir_reduce55 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState108) : 'freshtv420)
    | MenhirState114 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv421 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3029 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | IN ->
            _menhir_run116 _menhir_env (Obj.magic _menhir_stack) MenhirState115
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState115
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState115) : 'freshtv422)
    | MenhirState116 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv425 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3047 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState117
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((((('freshtv423 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3059 "parser.ml"
            )) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let ((((((_menhir_stack, _menhir_s), _, (x : (
# 15 "parser.mly"
       (Syntax.id)
# 3064 "parser.ml"
            ))), _, (ls_param : 'tv_FunParamListExpr)), _, (e : 'tv_Expr)), _), _, (e2 : 'tv_Expr)) = _menhir_stack in
            let _6 = () in
            let _4 = () in
            let _1 = () in
            let _v : 'tv_LetExpr = 
# 147 "parser.mly"
                                                          ( LetExp([(x, FunExp(ls_param, e))], e2) )
# 3072 "parser.ml"
             in
            _menhir_goto_LetExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv424)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState117) : 'freshtv426)
    | MenhirState119 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv429 * _menhir_state) * _menhir_state * 'tv_LetAndExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState120
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv427 * _menhir_state) * _menhir_state * 'tv_LetAndExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s), _, (ls : 'tv_LetAndExpr)), _, (e : 'tv_Expr)) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_LetExpr = 
# 146 "parser.mly"
                              ( LetExp(ls, e) )
# 3096 "parser.ml"
             in
            _menhir_goto_LetExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv428)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState120) : 'freshtv430)
    | MenhirState8 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv433 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv431 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState121 in
            ((let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce5 _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv432)
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState121
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState121) : 'freshtv434)
    | MenhirState126 | MenhirState7 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv439 * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | SEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv435 * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState125 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | DFUN ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | EMPTYLIST ->
                _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | EQ ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | FALSE ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | FUN ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | GT ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | ID _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState126 _v
            | IF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | INTV _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState126 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState126) : 'freshtv436)
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState125
        | RSQBRACKET ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv437 * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, (exp : 'tv_Expr)) = _menhir_stack in
            let _v : 'tv_ListItemExpr = 
# 164 "parser.mly"
             ( [exp] )
# 3186 "parser.ml"
             in
            _menhir_goto_ListItemExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv438)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState125) : 'freshtv440)
    | MenhirState5 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv443 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState128
        | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv441 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState128 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | EMPTYLIST ->
                _menhir_run136 _menhir_env (Obj.magic _menhir_stack) MenhirState129
            | ID _v ->
                _menhir_run133 _menhir_env (Obj.magic _menhir_stack) MenhirState129 _v
            | LSQBRACKET ->
                _menhir_run130 _menhir_env (Obj.magic _menhir_stack) MenhirState129
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState129) : 'freshtv442)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState128) : 'freshtv444)
    | MenhirState138 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv449 * _menhir_state * 'tv_MatchPatternExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | SEP ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv445 * _menhir_state * 'tv_MatchPatternExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState139 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | EMPTYLIST ->
                _menhir_run136 _menhir_env (Obj.magic _menhir_stack) MenhirState140
            | ID _v ->
                _menhir_run133 _menhir_env (Obj.magic _menhir_stack) MenhirState140 _v
            | LSQBRACKET ->
                _menhir_run130 _menhir_env (Obj.magic _menhir_stack) MenhirState140
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState140) : 'freshtv446)
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState139
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | THEN | TRUE | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv447 * _menhir_state * 'tv_MatchPatternExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, (match_pattern : 'tv_MatchPatternExpr)), _, (exp : 'tv_Expr)) = _menhir_stack in
            let _2 = () in
            let _v : 'tv_MatchListExprs = 
# 177 "parser.mly"
                                                   ( [(match_pattern, exp)] )
# 3257 "parser.ml"
             in
            _menhir_goto_MatchListExprs _menhir_env _menhir_stack _menhir_s _v) : 'freshtv448)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState139) : 'freshtv450)
    | MenhirState147 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv451 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3269 "parser.ml"
        )) * (
# 15 "parser.mly"
       (Syntax.id)
# 3273 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ANDKW ->
            _menhir_run91 _menhir_env (Obj.magic _menhir_stack) MenhirState148
        | LET ->
            _menhir_run149 _menhir_env (Obj.magic _menhir_stack) MenhirState148
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState148
        | IN | SEMISEMI ->
            _menhir_reduce61 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState148) : 'freshtv452)
    | MenhirState153 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv455 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3295 "parser.ml"
        )) * (
# 15 "parser.mly"
       (Syntax.id)
# 3299 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LET ->
            _menhir_run149 _menhir_env (Obj.magic _menhir_stack) MenhirState154
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState154
        | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv453 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3313 "parser.ml"
            )) * (
# 15 "parser.mly"
       (Syntax.id)
# 3317 "parser.ml"
            ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let (((((_menhir_stack, _menhir_s), _), _, (x : (
# 15 "parser.mly"
       (Syntax.id)
# 3322 "parser.ml"
            ))), (param : (
# 15 "parser.mly"
       (Syntax.id)
# 3326 "parser.ml"
            ))), _, (e : 'tv_Expr)) = _menhir_stack in
            let _5 = () in
            let _2 = () in
            let _1 = () in
            let _v : 'tv_TopLetRecExpr = 
# 42 "parser.mly"
                                  ( [(x, param, e)] )
# 3334 "parser.ml"
             in
            _menhir_goto_TopLetRecExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv454)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState154) : 'freshtv456)
    | MenhirState159 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv459 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3346 "parser.ml"
        )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 3350 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LET ->
            _menhir_run149 _menhir_env (Obj.magic _menhir_stack) MenhirState160
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState160
        | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((((('freshtv457 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3364 "parser.ml"
            )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 3368 "parser.ml"
            ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let (((((_menhir_stack, _menhir_s), _), _, (x : (
# 15 "parser.mly"
       (Syntax.id)
# 3373 "parser.ml"
            ))), (param : (
# 15 "parser.mly"
       (Syntax.id)
# 3377 "parser.ml"
            ))), _, (e : 'tv_Expr)) = _menhir_stack in
            let _7 = () in
            let _5 = () in
            let _4 = () in
            let _2 = () in
            let _1 = () in
            let _v : 'tv_TopLetRecExpr = 
# 43 "parser.mly"
                                             ( [(x, param, e)] )
# 3387 "parser.ml"
             in
            _menhir_goto_TopLetRecExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv458)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState160) : 'freshtv460)
    | MenhirState165 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv461 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3399 "parser.ml"
        )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 3403 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ANDKW ->
            _menhir_run98 _menhir_env (Obj.magic _menhir_stack) MenhirState166
        | LET ->
            _menhir_run149 _menhir_env (Obj.magic _menhir_stack) MenhirState166
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState166
        | IN | SEMISEMI ->
            _menhir_reduce62 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState166) : 'freshtv462)
    | MenhirState170 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv463 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3425 "parser.ml"
        )) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ANDKW ->
            _menhir_run109 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | LET ->
            _menhir_run172 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | IN | SEMISEMI ->
            _menhir_reduce55 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState171) : 'freshtv464)
    | MenhirState174 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv467 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3447 "parser.ml"
        )) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LET ->
            _menhir_run172 _menhir_env (Obj.magic _menhir_stack) MenhirState175
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState175
        | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv465 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3461 "parser.ml"
            )) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            ((let ((((_menhir_stack, _menhir_s), _, (x : (
# 15 "parser.mly"
       (Syntax.id)
# 3466 "parser.ml"
            ))), _), _, (e : 'tv_Expr)) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : 'tv_TopLetExpr = 
# 36 "parser.mly"
                     ( [(x, e)] )
# 3473 "parser.ml"
             in
            _menhir_goto_TopLetExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv466)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState175) : 'freshtv468)
    | MenhirState178 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv469 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3485 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState179
        | SEMISEMI ->
            _menhir_reduce84 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState179) : 'freshtv470)
    | MenhirState181 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv471 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3503 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | IN ->
            _menhir_run116 _menhir_env (Obj.magic _menhir_stack) MenhirState182
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState182
        | SEMISEMI ->
            _menhir_reduce84 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState182) : 'freshtv472)
    | MenhirState0 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv477 * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | SEMISEMI ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv475 * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState190 in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv473 * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
            let (_ : _menhir_state) = _menhir_s in
            ((let (_menhir_stack, _menhir_s, (e : 'tv_Expr)) = _menhir_stack in
            let _2 = () in
            let _v : (
# 18 "parser.mly"
      (Syntax.program)
# 3536 "parser.ml"
            ) = 
# 46 "parser.mly"
                  ( Exp e )
# 3540 "parser.ml"
             in
            _menhir_goto_toplevel _menhir_env _menhir_stack _menhir_s _v) : 'freshtv474)) : 'freshtv476)
        | TWOCOLONS ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState190
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState190) : 'freshtv478)
    | _ ->
        _menhir_fail ()

and _menhir_run105 : _menhir_env -> ('ttv_tail * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3555 "parser.ml"
)) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3559 "parser.ml"
) -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | DFUN ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | EMPTYLIST ->
        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | EQ ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | FALSE ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | FUN ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | GT ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | ID _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState105 _v
    | IF ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | INTV _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState105 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState105
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState105

and _menhir_reduce2 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _1 = () in
    let _v : 'tv_AExpr = 
# 122 "parser.mly"
         ( BLit true )
# 3615 "parser.ml"
     in
    _menhir_goto_AExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_PExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_PExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState0 | MenhirState181 | MenhirState178 | MenhirState174 | MenhirState170 | MenhirState165 | MenhirState159 | MenhirState153 | MenhirState147 | MenhirState138 | MenhirState5 | MenhirState126 | MenhirState7 | MenhirState8 | MenhirState119 | MenhirState116 | MenhirState114 | MenhirState107 | MenhirState105 | MenhirState101 | MenhirState96 | MenhirState13 | MenhirState88 | MenhirState86 | MenhirState15 | MenhirState22 | MenhirState55 | MenhirState43 | MenhirState28 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv313 * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv303 * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | DFUN ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState81
            | EMPTYLIST ->
                _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState81
            | FALSE ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState81
            | FUN ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState81
            | ID _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState81 _v
            | IF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState81
            | INTV _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState81 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState81
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState81
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState81
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState81
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState81
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState81
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState81
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState81) : 'freshtv304)
        | GT ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv305 * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | DFUN ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState79
            | EMPTYLIST ->
                _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState79
            | FALSE ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState79
            | FUN ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState79
            | ID _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState79 _v
            | IF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState79
            | INTV _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState79 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState79
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState79
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState79
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState79
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState79
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState79
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState79
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState79) : 'freshtv306)
        | LT ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv307 * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | DFUN ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState77
            | EMPTYLIST ->
                _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState77
            | FALSE ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState77
            | FUN ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState77
            | ID _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState77 _v
            | IF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState77
            | INTV _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState77 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState77
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState77
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState77
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState77
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState77
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState77
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState77
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState77) : 'freshtv308)
        | PLUS ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | ANDKW | ELSE | EMPTYLIST | FALSE | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | MULT | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv309 * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, (e : 'tv_PExpr)) = _menhir_stack in
            let _v : 'tv_EQExpr = 
# 80 "parser.mly"
            ( e )
# 3752 "parser.ml"
             in
            _menhir_goto_EQExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv310)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv311 * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv312)) : 'freshtv314)
    | MenhirState77 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv319 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | PLUS ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv315 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, (l : 'tv_PExpr)), _, (r : 'tv_PExpr)) = _menhir_stack in
            let _2 = () in
            let _v : 'tv_LTExpr = 
# 68 "parser.mly"
                       ( BinOp (Lt, l, r) )
# 3778 "parser.ml"
             in
            _menhir_goto_LTExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv316)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv317 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv318)) : 'freshtv320)
    | MenhirState79 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv325 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | PLUS ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv321 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, (l : 'tv_PExpr)), _, (r : 'tv_PExpr)) = _menhir_stack in
            let _2 = () in
            let _v : 'tv_GTExpr = 
# 73 "parser.mly"
                       ( BinOp (Gt, l, r) )
# 3804 "parser.ml"
             in
            _menhir_goto_GTExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv322)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv323 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv324)) : 'freshtv326)
    | MenhirState81 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv331 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | PLUS ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv327 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, (l : 'tv_PExpr)), _, (r : 'tv_PExpr)) = _menhir_stack in
            let _2 = () in
            let _v : 'tv_EQExpr = 
# 78 "parser.mly"
                       ( BinOp (Eq, l, r) )
# 3830 "parser.ml"
             in
            _menhir_goto_EQExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv328)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv329 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_PExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv330)) : 'freshtv332)
    | _ ->
        _menhir_fail ()

and _menhir_goto_OrExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_OrExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv301) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : 'tv_OrExpr) = _v in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv299) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((e : 'tv_OrExpr) : 'tv_OrExpr) = _v in
    ((let _v : 'tv_Expr = 
# 60 "parser.mly"
           ( e )
# 3856 "parser.ml"
     in
    _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv300)) : 'freshtv302)

and _menhir_goto_MExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_MExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState31 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv291 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_MExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | MULT ->
            _menhir_run34 _menhir_env (Obj.magic _menhir_stack)
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv287 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_MExpr) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, (l : 'tv_PExpr)), _, (r : 'tv_MExpr)) = _menhir_stack in
            let _2 = () in
            let _v : 'tv_PExpr = 
# 83 "parser.mly"
                         ( BinOp (Plus, l, r) )
# 3880 "parser.ml"
             in
            _menhir_goto_PExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv288)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv289 * _menhir_state * 'tv_PExpr)) * _menhir_state * 'tv_MExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv290)) : 'freshtv292)
    | MenhirState0 | MenhirState181 | MenhirState178 | MenhirState174 | MenhirState170 | MenhirState165 | MenhirState159 | MenhirState153 | MenhirState147 | MenhirState138 | MenhirState5 | MenhirState126 | MenhirState7 | MenhirState8 | MenhirState119 | MenhirState116 | MenhirState114 | MenhirState107 | MenhirState105 | MenhirState101 | MenhirState96 | MenhirState13 | MenhirState88 | MenhirState86 | MenhirState15 | MenhirState22 | MenhirState28 | MenhirState81 | MenhirState79 | MenhirState77 | MenhirState55 | MenhirState43 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv297 * _menhir_state * 'tv_MExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | MULT ->
            _menhir_run34 _menhir_env (Obj.magic _menhir_stack)
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv293 * _menhir_state * 'tv_MExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, (e : 'tv_MExpr)) = _menhir_stack in
            let _v : 'tv_PExpr = 
# 85 "parser.mly"
            ( e )
# 3905 "parser.ml"
             in
            _menhir_goto_PExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv294)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv295 * _menhir_state * 'tv_MExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv296)) : 'freshtv298)
    | _ ->
        _menhir_fail ()

and _menhir_goto_LTExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_LTExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv285) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : 'tv_LTExpr) = _v in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv283) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((e : 'tv_LTExpr) : 'tv_LTExpr) = _v in
    ((let _v : 'tv_Expr = 
# 56 "parser.mly"
           ( e )
# 3931 "parser.ml"
     in
    _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv284)) : 'freshtv286)

and _menhir_run11 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 15 "parser.mly"
       (Syntax.id)
# 3938 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | EQ ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv273 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3950 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | FUN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv269 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3960 "parser.ml"
            ))) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | ID _v ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv265 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3970 "parser.ml"
                )))) = Obj.magic _menhir_stack in
                let (_v : (
# 15 "parser.mly"
       (Syntax.id)
# 3975 "parser.ml"
                )) = _v in
                ((let _menhir_stack = (_menhir_stack, _v) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | RARROW ->
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : ((('freshtv261 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 3986 "parser.ml"
                    )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 3990 "parser.ml"
                    )) = Obj.magic _menhir_stack in
                    ((let _menhir_env = _menhir_discard _menhir_env in
                    let _tok = _menhir_env._menhir_token in
                    match _tok with
                    | AND ->
                        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | DFUN ->
                        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | EMPTYLIST ->
                        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | EQ ->
                        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | FALSE ->
                        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | FUN ->
                        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | GT ->
                        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | ID _v ->
                        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState96 _v
                    | IF ->
                        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | INTV _v ->
                        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState96 _v
                    | LET ->
                        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | LPAREN ->
                        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | LSQBRACKET ->
                        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | LT ->
                        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | MATCH ->
                        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | MULT ->
                        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | OR ->
                        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | PLUS ->
                        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | TRUE ->
                        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState96
                    | _ ->
                        assert (not _menhir_env._menhir_error);
                        _menhir_env._menhir_error <- true;
                        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState96) : 'freshtv262)
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : ((('freshtv263 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4044 "parser.ml"
                    )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 4048 "parser.ml"
                    )) = Obj.magic _menhir_stack in
                    ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv264)) : 'freshtv266)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv267 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4059 "parser.ml"
                )))) = Obj.magic _menhir_stack in
                ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv268)) : 'freshtv270)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv271 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4070 "parser.ml"
            ))) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv272)) : 'freshtv274)
    | ID _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv279 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4079 "parser.ml"
        )) = Obj.magic _menhir_stack in
        let (_v : (
# 15 "parser.mly"
       (Syntax.id)
# 4084 "parser.ml"
        )) = _v in
        ((let _menhir_stack = (_menhir_stack, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv275 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4095 "parser.ml"
            )) * (
# 15 "parser.mly"
       (Syntax.id)
# 4099 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | DFUN ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | EMPTYLIST ->
                _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | EQ ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | FALSE ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | FUN ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | GT ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | ID _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState13 _v
            | IF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | INTV _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState13 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState13
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState13) : 'freshtv276)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv277 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4153 "parser.ml"
            )) * (
# 15 "parser.mly"
       (Syntax.id)
# 4157 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv278)) : 'freshtv280)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv281 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4168 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv282)

and _menhir_run107 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4176 "parser.ml"
) -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | DFUN ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | EMPTYLIST ->
        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | EQ ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | FALSE ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | FUN ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | GT ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | ID _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState107 _v
    | IF ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | INTV _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState107 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState107
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState107

and _menhir_reduce1 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 14 "parser.mly"
       (int)
# 4229 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s (i : (
# 14 "parser.mly"
       (int)
# 4234 "parser.ml"
  )) ->
    let _v : 'tv_AExpr = 
# 121 "parser.mly"
         ( ILit i )
# 4239 "parser.ml"
     in
    _menhir_goto_AExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce4 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 15 "parser.mly"
       (Syntax.id)
# 4246 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s (i : (
# 15 "parser.mly"
       (Syntax.id)
# 4251 "parser.ml"
  )) ->
    let _v : 'tv_AExpr = 
# 124 "parser.mly"
         ( Var i )
# 4256 "parser.ml"
     in
    _menhir_goto_AExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_GTExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_GTExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv259) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : 'tv_GTExpr) = _v in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv257) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((e : 'tv_GTExpr) : 'tv_GTExpr) = _v in
    ((let _v : 'tv_Expr = 
# 57 "parser.mly"
           ( e )
# 4273 "parser.ml"
     in
    _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv258)) : 'freshtv260)

and _menhir_run19 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 15 "parser.mly"
       (Syntax.id)
# 4280 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState19 _v
    | EQ | RARROW ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv255 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4294 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, (id : (
# 15 "parser.mly"
       (Syntax.id)
# 4299 "parser.ml"
        ))) = _menhir_stack in
        let _v : 'tv_FunParamListExpr = 
# 160 "parser.mly"
        ( [id] )
# 4304 "parser.ml"
         in
        _menhir_goto_FunParamListExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv256)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState19

and _menhir_reduce3 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _1 = () in
    let _v : 'tv_AExpr = 
# 123 "parser.mly"
         ( BLit false )
# 4318 "parser.ml"
     in
    _menhir_goto_AExpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_EQExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_EQExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv253) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : 'tv_EQExpr) = _v in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv251) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((e : 'tv_EQExpr) : 'tv_EQExpr) = _v in
    ((let _v : 'tv_Expr = 
# 58 "parser.mly"
           ( e )
# 4335 "parser.ml"
     in
    _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv252)) : 'freshtv254)

and _menhir_goto_ListExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_ListExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState81 | MenhirState79 | MenhirState77 | MenhirState31 | MenhirState34 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv241 * _menhir_state * 'tv_ListExpr) = Obj.magic _menhir_stack in
        (_menhir_reduce6 _menhir_env (Obj.magic _menhir_stack) : 'freshtv242)
    | MenhirState0 | MenhirState181 | MenhirState178 | MenhirState174 | MenhirState170 | MenhirState165 | MenhirState159 | MenhirState153 | MenhirState147 | MenhirState138 | MenhirState5 | MenhirState126 | MenhirState7 | MenhirState8 | MenhirState119 | MenhirState116 | MenhirState114 | MenhirState107 | MenhirState105 | MenhirState101 | MenhirState96 | MenhirState13 | MenhirState88 | MenhirState86 | MenhirState15 | MenhirState22 | MenhirState28 | MenhirState55 | MenhirState43 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv247 * _menhir_state * 'tv_ListExpr) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ANDKW | ELSE | EMPTYLIST | EQ | FALSE | GT | ID _ | IN | INTV _ | LET | LPAREN | LSQBRACKET | LT | MULT | PLUS | RPAREN | RSQBRACKET | SEMI | SEMISEMI | SEP | THEN | TRUE | TWOCOLONS | WITH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv243 * _menhir_state * 'tv_ListExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, (e : 'tv_ListExpr)) = _menhir_stack in
            let _v : 'tv_Expr = 
# 64 "parser.mly"
             ( e )
# 4360 "parser.ml"
             in
            _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv244)
        | AND | OR ->
            _menhir_reduce6 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv245 * _menhir_state * 'tv_ListExpr) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv246)) : 'freshtv248)
    | MenhirState41 | MenhirState73 | MenhirState71 | MenhirState66 | MenhirState60 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv249 * _menhir_state * 'tv_ListExpr) = Obj.magic _menhir_stack in
        (_menhir_reduce6 _menhir_env (Obj.magic _menhir_stack) : 'freshtv250)
    | _ ->
        _menhir_fail ()

and _menhir_goto_AndExpr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_AndExpr -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv239) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : 'tv_AndExpr) = _v in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv237) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((e : 'tv_AndExpr) : 'tv_AndExpr) = _v in
    ((let _v : 'tv_Expr = 
# 59 "parser.mly"
            ( e )
# 4392 "parser.ml"
     in
    _menhir_goto_Expr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv238)) : 'freshtv240)

and _menhir_run104 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4399 "parser.ml"
) -> _menhir_state -> (
# 15 "parser.mly"
       (Syntax.id)
# 4403 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | EQ ->
        _menhir_run105 _menhir_env (Obj.magic _menhir_stack) MenhirState104
    | ID _v ->
        _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState104 _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState104

and _menhir_errorcase : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    match _menhir_s with
    | MenhirState190 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv63 * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv64)
    | MenhirState182 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv65 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4432 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv66)
    | MenhirState181 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv67 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4441 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv68)
    | MenhirState179 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv69 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4450 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv70)
    | MenhirState178 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv71 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4459 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv72)
    | MenhirState175 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv73 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4468 "parser.ml"
        )) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv74)
    | MenhirState174 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv75 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4477 "parser.ml"
        )) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv76)
    | MenhirState173 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv77 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4486 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv78)
    | MenhirState172 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv79 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv80)
    | MenhirState171 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv81 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4500 "parser.ml"
        )) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv82)
    | MenhirState170 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv83 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4509 "parser.ml"
        )) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv84)
    | MenhirState169 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv85 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4518 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv86)
    | MenhirState166 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv87 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4527 "parser.ml"
        )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 4531 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv88)
    | MenhirState165 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv89 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4540 "parser.ml"
        )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 4544 "parser.ml"
        ))) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv90)
    | MenhirState160 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv91 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4553 "parser.ml"
        )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 4557 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv92)
    | MenhirState159 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv93 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4566 "parser.ml"
        )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 4570 "parser.ml"
        ))) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv94)
    | MenhirState154 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv95 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4579 "parser.ml"
        )) * (
# 15 "parser.mly"
       (Syntax.id)
# 4583 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv96)
    | MenhirState153 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv97 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4592 "parser.ml"
        )) * (
# 15 "parser.mly"
       (Syntax.id)
# 4596 "parser.ml"
        ))) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv98)
    | MenhirState150 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv99 * _menhir_state) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv100)
    | MenhirState149 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv101 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv102)
    | MenhirState148 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv103 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4615 "parser.ml"
        )) * (
# 15 "parser.mly"
       (Syntax.id)
# 4619 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv104)
    | MenhirState147 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv105 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4628 "parser.ml"
        )) * (
# 15 "parser.mly"
       (Syntax.id)
# 4632 "parser.ml"
        ))) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv106)
    | MenhirState144 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv107 * _menhir_state) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv108)
    | MenhirState143 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv109 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv110)
    | MenhirState140 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv111 * _menhir_state * 'tv_MatchPatternExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv112)
    | MenhirState139 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv113 * _menhir_state * 'tv_MatchPatternExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv114)
    | MenhirState138 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv115 * _menhir_state * 'tv_MatchPatternExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv116)
    | MenhirState129 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv117 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv118)
    | MenhirState128 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv119 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv120)
    | MenhirState126 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv121 * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv122)
    | MenhirState125 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv123 * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv124)
    | MenhirState121 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv125 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv126)
    | MenhirState120 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv127 * _menhir_state) * _menhir_state * 'tv_LetAndExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv128)
    | MenhirState119 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv129 * _menhir_state) * _menhir_state * 'tv_LetAndExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv130)
    | MenhirState117 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv131 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4701 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv132)
    | MenhirState116 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv133 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4710 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv134)
    | MenhirState115 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv135 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4719 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv136)
    | MenhirState114 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv137 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4728 "parser.ml"
        )) * _menhir_state * 'tv_FunParamListExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv138)
    | MenhirState111 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv139 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4737 "parser.ml"
        )) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4741 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv140)
    | MenhirState110 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv141 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4750 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv142)
    | MenhirState109 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv143 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4759 "parser.ml"
        )) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv144)
    | MenhirState108 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv145 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4768 "parser.ml"
        )) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv146)
    | MenhirState107 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv147 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4777 "parser.ml"
        )) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv148)
    | MenhirState106 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv149 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4786 "parser.ml"
        )) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4790 "parser.ml"
        )) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv150)
    | MenhirState105 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv151 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4799 "parser.ml"
        )) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4803 "parser.ml"
        )) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv152)
    | MenhirState104 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv153 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4812 "parser.ml"
        )) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4816 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv154)
    | MenhirState103 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv155 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4825 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv156)
    | MenhirState102 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv157 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv158)
    | MenhirState101 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv159 * _menhir_state) * _menhir_state) * _menhir_state * 'tv_LetRecAndExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv160)
    | MenhirState98 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv161 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4844 "parser.ml"
        )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 4848 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv162)
    | MenhirState97 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv163 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4857 "parser.ml"
        )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 4861 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv164)
    | MenhirState96 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv165 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4870 "parser.ml"
        )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 4874 "parser.ml"
        ))) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv166)
    | MenhirState91 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv167 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4883 "parser.ml"
        )) * (
# 15 "parser.mly"
       (Syntax.id)
# 4887 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv168)
    | MenhirState90 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv169 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 4896 "parser.ml"
        )) * (
# 15 "parser.mly"
       (Syntax.id)
# 4900 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv170)
    | MenhirState89 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv171 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv172)
    | MenhirState88 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv173 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv174)
    | MenhirState87 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv175 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv176)
    | MenhirState86 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv177 * _menhir_state) * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv178)
    | MenhirState85 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv179 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv180)
    | MenhirState84 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv181 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr)) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv182)
    | MenhirState83 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv183 * _menhir_state) * (
# 15 "parser.mly"
       (Syntax.id)
# 4939 "parser.ml"
        ))) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv184)
    | MenhirState81 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv185 * _menhir_state * 'tv_PExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv186)
    | MenhirState79 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv187 * _menhir_state * 'tv_PExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv188)
    | MenhirState77 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv189 * _menhir_state * 'tv_PExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv190)
    | MenhirState73 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv191 * _menhir_state * 'tv_AExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv192)
    | MenhirState71 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv193 * _menhir_state * 'tv_AExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv194)
    | MenhirState66 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv195 * _menhir_state * 'tv_AExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv196)
    | MenhirState60 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv197 * _menhir_state * 'tv_AppExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv198)
    | MenhirState56 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv199 * _menhir_state * 'tv_Expr) * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv200)
    | MenhirState55 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv201 * _menhir_state * 'tv_Expr) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv202)
    | MenhirState54 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv203 * _menhir_state) * _menhir_state * 'tv_Expr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv204)
    | MenhirState43 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv205 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv206)
    | MenhirState41 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv207 * _menhir_state * 'tv_MExpr)) * _menhir_state * 'tv_AppExpr) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv208)
    | MenhirState34 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv209 * _menhir_state * 'tv_MExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv210)
    | MenhirState31 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv211 * _menhir_state * 'tv_PExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv212)
    | MenhirState28 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv213 * _menhir_state) * (
# 15 "parser.mly"
       (Syntax.id)
# 5018 "parser.ml"
        ))) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv214)
    | MenhirState22 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv215 * _menhir_state) * _menhir_state * 'tv_FunParamListExpr)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv216)
    | MenhirState19 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv217 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 5032 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv218)
    | MenhirState18 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv219 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv220)
    | MenhirState15 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv221 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv222)
    | MenhirState13 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv223 * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 5051 "parser.ml"
        )) * (
# 15 "parser.mly"
       (Syntax.id)
# 5055 "parser.ml"
        ))) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv224)
    | MenhirState10 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv225 * _menhir_state) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv226)
    | MenhirState9 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv227 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv228)
    | MenhirState8 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv229 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv230)
    | MenhirState7 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv231 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv232)
    | MenhirState5 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv233 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv234)
    | MenhirState0 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv235) = Obj.magic _menhir_stack in
        (raise _eRR : 'freshtv236)

and _menhir_run1 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce2 _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run2 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv61) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_PExpr = 
# 84 "parser.mly"
         ( OpFunExp (Plus) )
# 5104 "parser.ml"
     in
    _menhir_goto_PExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv62)

and _menhir_run3 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv59) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_OrExpr = 
# 104 "parser.mly"
       ( OpFunExp (Or) )
# 5118 "parser.ml"
     in
    _menhir_goto_OrExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv60)

and _menhir_run4 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv57) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_MExpr = 
# 94 "parser.mly"
         ( OpFunExp (Mult) )
# 5132 "parser.ml"
     in
    _menhir_goto_MExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv58)

and _menhir_run5 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | DFUN ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | EMPTYLIST ->
        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | EQ ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | FALSE ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | FUN ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | GT ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | ID _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState5 _v
    | IF ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | INTV _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState5 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState5
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState5

and _menhir_run6 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv55) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_LTExpr = 
# 69 "parser.mly"
       ( OpFunExp (Lt) )
# 5195 "parser.ml"
     in
    _menhir_goto_LTExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv56)

and _menhir_run7 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | DFUN ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | EMPTYLIST ->
        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | EQ ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | FALSE ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | FUN ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | GT ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | ID _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState7 _v
    | IF ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | INTV _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState7 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState7

and _menhir_run8 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | DFUN ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | EMPTYLIST ->
        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | EQ ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | FALSE ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | FUN ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | GT ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | ID _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _v
    | IF ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | INTV _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState8
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState8

and _menhir_run9 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv51 * _menhir_state) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState9 in
        let (_v : (
# 15 "parser.mly"
       (Syntax.id)
# 5310 "parser.ml"
        )) = _v in
        ((let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EQ ->
            _menhir_run107 _menhir_env (Obj.magic _menhir_stack) MenhirState103
        | ID _v ->
            _menhir_run104 _menhir_env (Obj.magic _menhir_stack) MenhirState103 _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState103) : 'freshtv52)
    | REC ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv53 * _menhir_state) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState9 in
        ((let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ID _v ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState10) : 'freshtv54)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState9

and _menhir_run14 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 14 "parser.mly"
       (int)
# 5346 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce1 _menhir_env (Obj.magic _menhir_stack) _menhir_s _v

and _menhir_run15 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | DFUN ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | EMPTYLIST ->
        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | EQ ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | FALSE ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | FUN ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | GT ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | ID _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState15 _v
    | IF ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | INTV _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState15 _v
    | LET ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState15
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState15

and _menhir_run16 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 15 "parser.mly"
       (Syntax.id)
# 5404 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce4 _menhir_env (Obj.magic _menhir_stack) _menhir_s _v

and _menhir_run17 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv49) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_GTExpr = 
# 74 "parser.mly"
       ( OpFunExp (Gt) )
# 5420 "parser.ml"
     in
    _menhir_goto_GTExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv50)

and _menhir_run18 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState18 _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState18

and _menhir_run23 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce3 _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run24 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv47) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_EQExpr = 
# 79 "parser.mly"
       ( OpFunExp (Eq) )
# 5452 "parser.ml"
     in
    _menhir_goto_EQExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv48)

and _menhir_run25 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv45) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_ListExpr = 
# 168 "parser.mly"
              ( ListExp ([]) )
# 5466 "parser.ml"
     in
    _menhir_goto_ListExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv46)

and _menhir_run26 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv41 * _menhir_state) = Obj.magic _menhir_stack in
        let (_v : (
# 15 "parser.mly"
       (Syntax.id)
# 5482 "parser.ml"
        )) = _v in
        ((let _menhir_stack = (_menhir_stack, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RARROW ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv37 * _menhir_state) * (
# 15 "parser.mly"
       (Syntax.id)
# 5493 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | AND ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | DFUN ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | EMPTYLIST ->
                _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | EQ ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | FALSE ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | FUN ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | GT ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | ID _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState28 _v
            | IF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | INTV _v ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState28 _v
            | LET ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | LPAREN ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | LSQBRACKET ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | LT ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | MATCH ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | MULT ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | PLUS ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | TRUE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState28
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState28) : 'freshtv38)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv39 * _menhir_state) * (
# 15 "parser.mly"
       (Syntax.id)
# 5547 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv40)) : 'freshtv42)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv43 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv44)

and _menhir_run29 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv35) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_AndExpr = 
# 100 "parser.mly"
        ( OpFunExp (And) )
# 5569 "parser.ml"
     in
    _menhir_goto_AndExpr _menhir_env _menhir_stack _menhir_s _v) : 'freshtv36)

and _menhir_discard : _menhir_env -> _menhir_env =
  fun _menhir_env ->
    let lexer = _menhir_env._menhir_lexer in
    let lexbuf = _menhir_env._menhir_lexbuf in
    let _tok = lexer lexbuf in
    {
      _menhir_lexer = lexer;
      _menhir_lexbuf = lexbuf;
      _menhir_token = _tok;
      _menhir_error = false;
    }

and toplevel : (Lexing.lexbuf -> token) -> Lexing.lexbuf -> (
# 18 "parser.mly"
      (Syntax.program)
# 5588 "parser.ml"
) =
  fun lexer lexbuf ->
    let _menhir_env =
      let (lexer : Lexing.lexbuf -> token) = lexer in
      let (lexbuf : Lexing.lexbuf) = lexbuf in
      ((let _tok = Obj.magic () in
      {
        _menhir_lexer = lexer;
        _menhir_lexbuf = lexbuf;
        _menhir_token = _tok;
        _menhir_error = false;
      }) : _menhir_env)
    in
    Obj.magic (let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv33) = ((), _menhir_env._menhir_lexbuf.Lexing.lex_curr_p) in
    ((let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AND ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | DFUN ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | EMPTYLIST ->
        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | EQ ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | FALSE ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | FUN ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | GT ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | ID _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _v
    | IF ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | INTV _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _v
    | LET ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv31) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState0 in
        ((let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | ID _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv3 * _menhir_state) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState143 in
            let (_v : (
# 15 "parser.mly"
       (Syntax.id)
# 5642 "parser.ml"
            )) = _v in
            ((let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | EQ ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv1 * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 5653 "parser.ml"
                )) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = MenhirState169 in
                ((let _menhir_stack = (_menhir_stack, _menhir_s) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | AND ->
                    _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | DFUN ->
                    _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | EMPTYLIST ->
                    _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | EQ ->
                    _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | FALSE ->
                    _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | FUN ->
                    _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | GT ->
                    _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | ID _v ->
                    _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState170 _v
                | IF ->
                    _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | INTV _v ->
                    _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState170 _v
                | LET ->
                    _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | LPAREN ->
                    _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | LSQBRACKET ->
                    _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | LT ->
                    _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | MATCH ->
                    _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | MULT ->
                    _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | OR ->
                    _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | PLUS ->
                    _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | TRUE ->
                    _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState170
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState170) : 'freshtv2)
            | ID _v ->
                _menhir_run104 _menhir_env (Obj.magic _menhir_stack) MenhirState169 _v
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState169) : 'freshtv4)
        | REC ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv29 * _menhir_state) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState143 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | ID _v ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv27 * _menhir_state) * _menhir_state) = Obj.magic _menhir_stack in
                let (_menhir_s : _menhir_state) = MenhirState144 in
                let (_v : (
# 15 "parser.mly"
       (Syntax.id)
# 5723 "parser.ml"
                )) = _v in
                ((let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | EQ ->
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : (('freshtv17 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 5734 "parser.ml"
                    )) = Obj.magic _menhir_stack in
                    ((let _menhir_env = _menhir_discard _menhir_env in
                    let _tok = _menhir_env._menhir_token in
                    match _tok with
                    | FUN ->
                        let (_menhir_env : _menhir_env) = _menhir_env in
                        let (_menhir_stack : ((('freshtv13 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 5744 "parser.ml"
                        ))) = Obj.magic _menhir_stack in
                        ((let _menhir_env = _menhir_discard _menhir_env in
                        let _tok = _menhir_env._menhir_token in
                        match _tok with
                        | ID _v ->
                            let (_menhir_env : _menhir_env) = _menhir_env in
                            let (_menhir_stack : (((('freshtv9 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 5754 "parser.ml"
                            )))) = Obj.magic _menhir_stack in
                            let (_v : (
# 15 "parser.mly"
       (Syntax.id)
# 5759 "parser.ml"
                            )) = _v in
                            ((let _menhir_stack = (_menhir_stack, _v) in
                            let _menhir_env = _menhir_discard _menhir_env in
                            let _tok = _menhir_env._menhir_token in
                            match _tok with
                            | RARROW ->
                                let (_menhir_env : _menhir_env) = _menhir_env in
                                let (_menhir_stack : ((((('freshtv5 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 5770 "parser.ml"
                                )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 5774 "parser.ml"
                                )) = Obj.magic _menhir_stack in
                                ((let _menhir_env = _menhir_discard _menhir_env in
                                let _tok = _menhir_env._menhir_token in
                                match _tok with
                                | AND ->
                                    _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | DFUN ->
                                    _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | EMPTYLIST ->
                                    _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | EQ ->
                                    _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | FALSE ->
                                    _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | FUN ->
                                    _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | GT ->
                                    _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | ID _v ->
                                    _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState165 _v
                                | IF ->
                                    _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | INTV _v ->
                                    _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState165 _v
                                | LET ->
                                    _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | LPAREN ->
                                    _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | LSQBRACKET ->
                                    _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | LT ->
                                    _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | MATCH ->
                                    _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | MULT ->
                                    _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | OR ->
                                    _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | PLUS ->
                                    _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | TRUE ->
                                    _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState165
                                | _ ->
                                    assert (not _menhir_env._menhir_error);
                                    _menhir_env._menhir_error <- true;
                                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState165) : 'freshtv6)
                            | _ ->
                                assert (not _menhir_env._menhir_error);
                                _menhir_env._menhir_error <- true;
                                let (_menhir_env : _menhir_env) = _menhir_env in
                                let (_menhir_stack : ((((('freshtv7 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 5828 "parser.ml"
                                )))) * (
# 15 "parser.mly"
       (Syntax.id)
# 5832 "parser.ml"
                                )) = Obj.magic _menhir_stack in
                                ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
                                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv8)) : 'freshtv10)
                        | _ ->
                            assert (not _menhir_env._menhir_error);
                            _menhir_env._menhir_error <- true;
                            let (_menhir_env : _menhir_env) = _menhir_env in
                            let (_menhir_stack : (((('freshtv11 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 5843 "parser.ml"
                            )))) = Obj.magic _menhir_stack in
                            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv12)) : 'freshtv14)
                    | _ ->
                        assert (not _menhir_env._menhir_error);
                        _menhir_env._menhir_error <- true;
                        let (_menhir_env : _menhir_env) = _menhir_env in
                        let (_menhir_stack : ((('freshtv15 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 5854 "parser.ml"
                        ))) = Obj.magic _menhir_stack in
                        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv16)) : 'freshtv18)
                | ID _v ->
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : (('freshtv23 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 5863 "parser.ml"
                    )) = Obj.magic _menhir_stack in
                    let (_v : (
# 15 "parser.mly"
       (Syntax.id)
# 5868 "parser.ml"
                    )) = _v in
                    ((let _menhir_stack = (_menhir_stack, _v) in
                    let _menhir_env = _menhir_discard _menhir_env in
                    let _tok = _menhir_env._menhir_token in
                    match _tok with
                    | EQ ->
                        let (_menhir_env : _menhir_env) = _menhir_env in
                        let (_menhir_stack : ((('freshtv19 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 5879 "parser.ml"
                        )) * (
# 15 "parser.mly"
       (Syntax.id)
# 5883 "parser.ml"
                        )) = Obj.magic _menhir_stack in
                        ((let _menhir_env = _menhir_discard _menhir_env in
                        let _tok = _menhir_env._menhir_token in
                        match _tok with
                        | AND ->
                            _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | DFUN ->
                            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | EMPTYLIST ->
                            _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | EQ ->
                            _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | FALSE ->
                            _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | FUN ->
                            _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | GT ->
                            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | ID _v ->
                            _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState147 _v
                        | IF ->
                            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | INTV _v ->
                            _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState147 _v
                        | LET ->
                            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | LPAREN ->
                            _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | LSQBRACKET ->
                            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | LT ->
                            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | MATCH ->
                            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | MULT ->
                            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | OR ->
                            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | PLUS ->
                            _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | TRUE ->
                            _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState147
                        | _ ->
                            assert (not _menhir_env._menhir_error);
                            _menhir_env._menhir_error <- true;
                            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState147) : 'freshtv20)
                    | _ ->
                        assert (not _menhir_env._menhir_error);
                        _menhir_env._menhir_error <- true;
                        let (_menhir_env : _menhir_env) = _menhir_env in
                        let (_menhir_stack : ((('freshtv21 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 5937 "parser.ml"
                        )) * (
# 15 "parser.mly"
       (Syntax.id)
# 5941 "parser.ml"
                        )) = Obj.magic _menhir_stack in
                        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
                        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv22)) : 'freshtv24)
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : (('freshtv25 * _menhir_state) * _menhir_state) * _menhir_state * (
# 15 "parser.mly"
       (Syntax.id)
# 5952 "parser.ml"
                    )) = Obj.magic _menhir_stack in
                    ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv26)) : 'freshtv28)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState144) : 'freshtv30)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState143) : 'freshtv32)
    | LPAREN ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | LSQBRACKET ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | LT ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | MATCH ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | MULT ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | OR ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | PLUS ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | TRUE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState0) : 'freshtv34))

# 219 "/export/home/015/a0158050/.opam/4.03.0/lib/menhir/standard.mly"
  


# 5989 "parser.ml"
