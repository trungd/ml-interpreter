let x = true && (false || false);;
(1 < 0) && (2 < 1);;
(1 < 0) || (1 > 0);;
if (1 > 2) && (3 > 2) then 5 else 4;;