let f = fun a b -> a;;
let g = f f f f f;;
g 5 6;;