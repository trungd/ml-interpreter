
let x = 4 + 5;;
(*abc*) 5;;
(*abc*) let y = x + 2 (*abc*);;(*abc*)
(*This is a long comment
This is a long comment
This is a long comment*)
4;;