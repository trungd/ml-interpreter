v + iii * 2;;
v + ii * iv - x;;
iv + iii * 2;;